#Potohar district data analysis
#might have to run other distrits analysis
library(dataRetrieval)
library(xts)
library(timeDate)
library(lubridate)
library(ggplot2)
library(raster)
library(rgdal)
library(sf)
library(maptools)
library(mapproj)
library(maps)
library(sp)
library(RColorBrewer)
library(viridis)
library(viridisLite)
library(rasterVis)
library(chron)
library(lPotice)
library(ncdf4)
library(rgeos)
library(gridExtra)
library(PBSmapping)
library(na.tools)
library(readxl)
library(writexl)
library(corrplot)
library(dplyr)
library(clusterSim)
library(tidyr)
library(rsample)   # data splitting 
library(ggplot2)   # plotting
library(earth)     # fit MARS models
library(caret)     # automating the tuning process
library(vip)       # variable importance
library(pdp) 
library(caTools)
library(MLmetrics)
library(olsrr)
library(MASS)
library(leaps)
library(openxlsx)
library(broom)

#rounding function
round_df <- function(df, digits) {
  nums <- vapply(df, is.numeric, FUN.VALUE = logical(1))
  
  df[,nums] <- round(df[,nums], digits = digits)
  
  (df)
}

#upload data
Potohar_Wheat <- read_excel('C:/Users/Ryan/Box/NASA_WEF/data/Features/Potohar_HR_Features.xlsx')
Potohar_Wheat$Ln_Wheat <- NULL

#Set train data the same as other python models, WK_14_Minweekly_SM_0_10cm
rem1 <- read.csv('C:/Users/Ryan/Box/NASA_WEF/output/V2/RF/Season_Week_Month_top5/DataWithPredictedValues.csv')
rem1 <- rem1$WK_14_Minweekly_SM_0_10cm

#Potohar training datat
Potohar_Wheat <- subset(Potohar_Wheat, !WK_14_Minweekly_SM_0_10cm %in% rem1)


#Selecting only Precip
#subset the data to just deal with features of importance and yield
require(PerformanceAnalytics)
Features <- head(Potohar_Wheat[,c('Wheat_ton_ha', 
                                  colnames(Potohar_Wheat)[grep('mm',colnames(Potohar_Wheat))],
                                  colnames(Potohar_Wheat)[grep('Precip_hours',colnames(Potohar_Wheat))])])
Features <- colnames(Features)

#DF
#make a Potohar wheat DF of just Precipitation
DF <- Potohar_Wheat[Features]

#R1
#need to remove odd metrics that mess up model or are meaningless
#These are the selected variable for the step model, need to be reran
RemFeatures <- head(Potohar_Wheat[,c(
  'NovandJan_Mar_below8mmhr','WK_16_weekly_Precip_below12mmhr','Jan_Maxmonthly_Precip_mmhr',
  'WK_10_Maxweekly_Precip_mmhr','WK_23_Maxweekly_Precip_mmhr','Nov_monthly_Precip_above8mmhr',
  'WK_21_weekly_Precip_above8mmhr','WK_2_weekly_Precip_below8mmhr','WK_7_weekly_Precip_hours',
  'Feb_monthly_Precip_above8mmhr','WK_5_weekly_Precip_hours','WK_14_weekly_Precip_1_5mmhr',
  'WK_9_weekly_Precip_above5mmhr','WK_18_weekly_Precip_5_8mmhr','WK_22_weekly_Precip_8_12mmhr',
  'WK_4_Maxweekly_Precip_mmhr','DecandApr_Precip_hours','WK_11_weekly_Precip_above8mmhr',
  'WK_18_weekly_Precip_hours','NovandApr_1_5mmhr','WK_16_weekly_Precip_hours',
  'WK_20_weekly_Precip_above2mmhr','WK_23_weekly_Precip_1_5mmhr','Apr_Maxmonthly_Precip_mmhr',
  'WK_7_Sumweekly_Precip_mm', 'Jan_Apr_above2mmhr', 'WK_9_weekly_Precip_above2mmhr',
  'WK_2_weekly_Precip_above5mmhr','NovandApr_Precip_hours','Max_Season_Precip_mmhr',
  'WK_23_weekly_Precip_below8mmhr','WK_1_weekly_Precip_hours','WK_7_Maxweekly_Precip_mmhr',
  'WK_9_Sumweekly_Precip_mm','WK_19_weekly_Precip_above5mmhr', 
  'Jan_Mar_below8mmhr', 'WK_12_weekly_Precip_above5mmhr', 'WK_2_Sumweekly_Precip_mm',
  'WK_2_Maxweekly_Precip_mmhr','WK_17_weekly_Precip_above8mmhr','WK_17_Maxweekly_Precip_mmhr',
  'DecandMar_below12mmhr','WK_15_weekly_Precip_above2mmhr','WK_15_weekly_Precip_below15mmhr',
  'WK_7_weekly_Precip_1_5mmhr','Jan_monthly_Precip_above8mmhr','DecandMar_above2mmhr',
  'FebandApr_5_8mmhr','WK_13_weekly_Precip_above8mmhr','WK_11_weekly_Precip_hours',
  'MinMonth_Season_Precip_mm', 'Jan_Feb_above5mmhr', 'WK_18_Maxweekly_Precip_mmhr',
  'Mar_monthly_Precip_8_12mmhr', 'Nov_Mar_Precip_hours', 'WK_12_Maxweekly_Precip_mmhr',
  'Nov_Mar_12_15mmhr', 'WK_20_Sumweekly_Precip_mm', 'Jan_Apr_1_5mmhr',
  'Nov_Dec_5_8mmhr', 'Apr_Summonthly_Precip_mm', 'MaxMonth_Season_Precip_mm',
  'WK_17_Sumweekly_Precip_mm', 'Feb_Mar_above5mmhr', 'Mar_monthly_Precip_above5mmhr',
  'Nov_Maxmonthly_Precip_mmhr', 'Wheat_ton_ha'
)])
RemFeatures <- colnames(RemFeatures)
#make a dataframe without off air temps
DFR1 <- Potohar_Wheat[RemFeatures]


#R2
#need to remove odd metrics that mess up model or are meaningless
RemFeatures2 <- head(DF[,colnames(DF)[grep('below',colnames(DF))]])
RemFeatures3 <- head(DF[,c('Dec_Apr_1_5mmhr',colnames(DF)[grep('2mmhr',colnames(DF))])])
RemFeatures2 <- colnames(RemFeatures2)
RemFeatures3 <- colnames(RemFeatures3)

RemFeatures2 <- setdiff(Features, RemFeatures2)
RemFeatures2 <- setdiff(RemFeatures2, RemFeatures3)

#make new refined precip dataframe
DFR2 <- Potohar_Wheat[RemFeatures2]

#R3
#make a dataframe without mmhr
RemFeatures3 <- head(DFR2[,colnames(DFR2)[grep('mmhr',colnames(DFR2))]])
RemFeatures3 <- colnames(RemFeatures3)
RemFeatures3 <- setdiff(RemFeatures2, RemFeatures3)
DFR3 <- DFR2[RemFeatures3]

#R4
#make a dataframe without precip hours and mmhr
RemFeatures4  <- head(DFR3[,colnames(DFR3)[grep('hours',colnames(DFR3))]])
RemFeatures4 <- colnames(RemFeatures4)
RemFeatures4 <- setdiff(RemFeatures3, RemFeatures4)
DFR4 <- DFR3[RemFeatures4]

#DF
#Look at the correlated features of the most important variables, All DF
Features_Cor <- data.frame(cor(DF$Wheat_ton_ha, DF))
Features_Cor <- data.frame(t(Features_Cor))
colnames(Features_Cor) <- 'Correlation'
Features_Cor$Variable <- rownames(Features_Cor)
Features_Cor$Correlation <- abs(Features_Cor$Correlation)
Features_Cor <-  Features_Cor[order(Features_Cor$Correlation,decreasing=TRUE),]

#R1
#Look at the correlated features of the most important variables, DF mmhr rem
Features_CorR1 <- data.frame(cor(DFR1$Wheat_ton_ha, DFR1))
Features_CorR1 <- data.frame(t(Features_CorR1))
colnames(Features_CorR1) <- 'Correlation'
Features_CorR1$Variable <- rownames(Features_CorR1)
Features_CorR1$Correlation <- abs(Features_CorR1$Correlation)
Features_CorR1 <-  Features_CorR1[order(Features_CorR1$Correlation,decreasing=TRUE),]

#R2
#Look at the correlated features of the most important variables, DF mmhr rem
Features_CorR2 <- data.frame(cor(DFR2$Wheat_ton_ha, DFR2))
Features_CorR2 <- data.frame(t(Features_CorR2))
colnames(Features_CorR2) <- 'Correlation'
Features_CorR2$Variable <- rownames(Features_CorR2)
Features_CorR2$Correlation <- abs(Features_CorR2$Correlation)
Features_CorR2 <-  Features_CorR2[order(Features_CorR2$Correlation,decreasing=TRUE),]

#R3
#Look at the correlated features of the most important variables, DF mmhr rem
Features_CorR3 <- data.frame(cor(DFR3$Wheat_ton_ha, DFR3))
Features_CorR3 <- data.frame(t(Features_CorR3))
colnames(Features_CorR3) <- 'Correlation'
Features_CorR3$Variable <- rownames(Features_CorR3)
Features_CorR3$Correlation <- abs(Features_CorR3$Correlation)
Features_CorR3 <-  Features_CorR3[order(Features_CorR3$Correlation,decreasing=TRUE),]


#R4
#Look at the correlated features of the most important variables, DF mmhr rem
Features_CorR4 <- data.frame(cor(DFR4$Wheat_ton_ha, DFR4))
Features_CorR4 <- data.frame(t(Features_CorR4))
colnames(Features_CorR4) <- 'Correlation'
Features_CorR4$Variable <- rownames(Features_CorR4)
Features_CorR4$Correlation <- abs(Features_CorR4$Correlation)
Features_CorR4 <-  Features_CorR4[order(Features_CorR4$Correlation,decreasing=TRUE),]



#Take top features to make model. c > 0.40, all precip
Features2 <- subset(Features_Cor, Correlation > 0.40)
Features2 <- Features2$Variable

#Take top features to make model. c > 0.40, all precip
Features2R1 <- subset(Features_CorR1, Correlation > 0.40)
Features2R1 <- Features2R1$Variable

#Take top features to make model. c > 0.40, all precip
Features2R2 <- subset(Features_CorR2, Correlation > 0.40)
Features2R2 <- Features2R2$Variable

#Take top features to make model. c > 0.40, all precip
Features2R3 <- subset(Features_CorR3, Correlation > 0.40)
Features2R3 <- Features2R3$Variable

#Take top features to make model. c > 0.40, all precip
Features2R4 <- subset(Features_CorR4, Correlation > 0.40)
Features2R4 <- Features2R4$Variable


#building model with just top 20 most correlcated features
DF <- Potohar_Wheat[Features2]
DFR1 <- Potohar_Wheat[Features2R1]
DFR2<- Potohar_Wheat[Features2R2]
DFR3<- Potohar_Wheat[Features2R3]
DFR4<- Potohar_Wheat[Features2R4]



#Leaps
#All precipitation
#leap Forward
# Set seed for reproducibility
set.seed(123)
# Set up repeated 10 k-fold cross-validation
#This method tunes model based on reducing RMSE
train.control <- trainControl(method = "cv", number = 5)
# Train the model
#methods <- c('leapBackward','leapForward','leapSeq' )
Mod_LF <- train(Wheat_ton_ha ~ ., data=DF,
                    method = 'leapForward', 
                    tuneGrid = data.frame(nvmax = 1:10),
                    trControl = train.control)

Model_STATS_LF <- data.frame(Mod_LF$results)

#determine the best variables
var <- Mod_LF$bestTune
var
Coef_LF <- data.frame(coef(Mod_LF$finalModel, var$nvmax))
Coef_LF$Feature <- rownames(Coef_LF)
Coef_LF <- Coef_LF[,c(2,1)]
rownames(Coef_LF) <- c()
colnames(Coef_LF)[2] <- 'Coefficient'

#make model with these coefs
Coef_LF <- subset(Coef_LF, Feature !='(Intercept)')
Coef_LF[nrow(Coef_LF)+1,] <- c('Wheat_ton_ha', NA)
DF_LF <- DF[Coef_LF$Feature]

#make model as a function of these parameters
All_Mod_LF <- lm(Wheat_ton_ha~., data=DF_LF)
summary(All_Mod_LF)
All_Mod_LF_Stats <- data.frame(tidy(All_Mod_LF))
colnames(All_Mod_LF_Stats) <- c('Variable', 'Coefficient', 'std error', 't_stat', 'p_value')
All_Mod_LF_Stats <- All_Mod_LF_Stats[order(All_Mod_LF_Stats$p_value),]
All_Mod_LF_Stats <- round_df(All_Mod_LF_Stats, digits = 3)


# Set up repeated 10 k-fold cross-validation
#This method tunes model based on reducing RMSE
# Train the model
set.seed(123)
Mod_LB <- train(Wheat_ton_ha ~ ., data=DF,
                method = 'leapBackward', 
                tuneGrid = data.frame(nvmax = 1:10),
                trControl = train.control)

Model_STATS_LB <- data.frame(Mod_LB$results)

#determine the best variables
var <- Mod_LB$bestTune
var
Coef_LB <- data.frame(coef(Mod_LB$finalModel, var$nvmax))
Coef_LB$Feature <- rownames(Coef_LB)
Coef_LB <- Coef_LB[,c(2,1)]
rownames(Coef_LB) <- c()
colnames(Coef_LB)[2] <- 'Coefficient'

#make model with these coefs
Coef_LB <- subset(Coef_LB, Feature !='(Intercept)')
Coef_LB[nrow(Coef_LB)+1,] <- c('Wheat_ton_ha', NA)
DF_LB <- DF[Coef_LB$Feature]

#make model as a function of these parameters
All_Mod_LB <- lm(Wheat_ton_ha~., data=DF_LB)
summary(All_Mod_LB)
All_Mod_LB_Stats <- data.frame(tidy(All_Mod_LB))
colnames(All_Mod_LB_Stats) <- c('Variable', 'Coefficient', 'std error', 't_stat', 'p_value')
All_Mod_LB_Stats <- All_Mod_LB_Stats[order(All_Mod_LB_Stats$p_value),]
All_Mod_LB_Stats <- round_df(All_Mod_LB_Stats, digits = 3)

#BAsic step function no CV
## Full model
mod.1 <- lm(Wheat_ton_ha ~ ., data=DF)
## Null model
mod.0 <- lm(Wheat_ton_ha ~ 1, data=DF)
mod.Final <- step(mod.0, scope = formula(mod.1))
summary(mod.Final)
All_SF_Stats <- data.frame(tidy(mod.Final))
colnames(All_SF_Stats) <- c('Variable', 'Coefficient', 'std error', 't-stat', 'p_value')
All_SF_Stats <- All_SF_Stats[order(All_SF_Stats$p_value),]
All_SF_Stats <- round_df(All_SF_Stats, digits = 3)



#Save All Precipitation Data
list_of_datasets <- list("Model LB" = Model_STATS_LB, "Model_Stats_LB" = All_Mod_LB_Stats,
                         "Model LF" = Model_STATS_LF, "Model_Stats_LF" = All_Mod_LF_Stats,
                         'Model_Stats_SF' = All_SF_Stats)
write.xlsx(list_of_datasets, file = "C:/Users/Ryan/Box/NASA_WEF/output/Cat_R2/AllPrecip.xlsx")









#Leaps
#Precip, R1
#leap Forward
# Set seed for reproducibility
set.seed(123)
# Train the model
Mod_LF <- train(Wheat_ton_ha ~ ., data=DFR1,
                method = 'leapForward', 
                tuneGrid = data.frame(nvmax = 1:4),
                trControl = train.control)

Model_STATS_LF <- data.frame(Mod_LF$results)

#determine the best variables
var <- Mod_LF$bestTune
var
Coef_LF <- data.frame(coef(Mod_LF$finalModel, var$nvmax))
Coef_LF$Feature <- rownames(Coef_LF)
Coef_LF <- Coef_LF[,c(2,1)]
rownames(Coef_LF) <- c()
colnames(Coef_LF)[2] <- 'Coefficient'

#make model with these coefs
Coef_LF <- subset(Coef_LF, Feature !='(Intercept)')
Coef_LF[nrow(Coef_LF)+1,] <- c('Wheat_ton_ha', NA)
DFR1_LF <- DFR1[Coef_LF$Feature]


#make model as a function of these parameters
AdjMod_LF <- lm(Wheat_ton_ha~., data=DFR1_LF)
summary(AdjMod_LF)
AdjMod_LF_Stats <- data.frame(tidy(AdjMod_LF))
colnames(AdjMod_LF_Stats) <- c('Variable', 'Coefficient', 'std error', 't_stat', 'p_value')
AdjMod_LF_Stats <- AdjMod_LF_Stats[order(AdjMod_LF_Stats$p_value),]
AdjMod_LF_Stats <- round_df(AdjMod_LF_Stats, digits = 3)


#leap Backwards
# Set seed for reproducibility
set.seed(123)
# Train the model
Mod_LB <- train(Wheat_ton_ha ~ ., data=DFR1,
                method = 'leapBackward', 
                tuneGrid = data.frame(nvmax = 1:4),
                trControl = train.control)

Model_STATS_LB <- data.frame(Mod_LB$results)

#determine the best variables
var <- Mod_LB$bestTune
var
Coef_LB <- data.frame(coef(Mod_LB$finalModel, var$nvmax))
Coef_LB$Feature <- rownames(Coef_LB)
Coef_LB <- Coef_LB[,c(2,1)]
rownames(Coef_LB) <- c()
colnames(Coef_LB)[2] <- 'Coefficient'

#make model with these coefs
Coef_LB <- subset(Coef_LB, Feature !='(Intercept)')
Coef_LB[nrow(Coef_LB)+1,] <- c('Wheat_ton_ha', NA)
DFR1_LB <- DFR1[Coef_LB$Feature]

#make model as a function of these parameters
AdjMod_LB <- lm(Wheat_ton_ha~., data=DFR1_LB)
summary(AdjMod_LB)
AdjMod_LB_Stats <- data.frame(tidy(AdjMod_LB))
colnames(AdjMod_LB_Stats) <- c('Variable', 'Coefficient', 'std error', 't_stat', 'p_value')
AdjMod_LB_Stats <- AdjMod_LB_Stats[order(AdjMod_LB_Stats$p_value),]
AdjMod_LB_Stats <- round_df(AdjMod_LB_Stats, digits = 3)


#BAsic step function no CV
## Full model
mod.1 <- lm(Wheat_ton_ha ~ ., data=DFR1)
## Null model
mod.0 <- lm(Wheat_ton_ha ~ 1, data=DFR1)
mod.Final <- step(mod.0, scope = formula(mod.1))
summary(mod.Final)
AdjMod_SF_Stats <- data.frame(tidy(mod.Final))
colnames(AdjMod_SF_Stats) <- c('Variable', 'Coefficient', 'std error', 't-stat', 'p_value')
AdjMod_SF_Stats <- AdjMod_SF_Stats[order(AdjMod_SF_Stats$p_value),]
AdjMod_SF_Stats <- round_df(AdjMod_SF_Stats, digits = 3)



#Save All Precipitation Data
list_of_datasets <- list("Model LB" = Model_STATS_LB, "Model_Stats_LB" = AdjMod_LB_Stats,
                         "Model LF" = Model_STATS_LF, "Model_Stats_LF" = AdjMod_LF_Stats,
                         'Model_AdjMod_SF_Stats' = AdjMod_SF_Stats)
write.xlsx(list_of_datasets, file = "C:/Users/Ryan/Box/NASA_WEF/output/Cat_R2/PrecipDFR1.xlsx")











#Leaps
#Precip, mmhr , R2
#leap Forward
# Set seed for reproducibility
set.seed(123)
# Set up repeated 10 k-fold cross-validation
#This method tunes model based on reducing RMSE
train.control <- trainControl(method = "cv", number = 5)
# Train the model
#methods <- c('leapBackward','leapForward','leapSeq' )
Mod_LF <- train(Wheat_ton_ha ~ ., data=DFR2,
                method = 'leapForward', 
                tuneGrid = data.frame(nvmax = 1:6),
                trControl = train.control)

Model_STATS_LF <- data.frame(Mod_LF$results)

#determine the best variables
var <- Mod_LF$bestTune
var
Coef_LF <- data.frame(coef(Mod_LF$finalModel, var$nvmax))
Coef_LF$Feature <- rownames(Coef_LF)
Coef_LF <- Coef_LF[,c(2,1)]
rownames(Coef_LF) <- c()
colnames(Coef_LF)[2] <- 'Coefficient'

#make model with these coefs
Coef_LF <- subset(Coef_LF, Feature !='(Intercept)')
Coef_LF[nrow(Coef_LF)+1,] <- c('Wheat_ton_ha', NA)
DFR2_LF <- DFR2[Coef_LF$Feature]


#make model as a function of these parameters
AdjMod_LF2 <- lm(Wheat_ton_ha~., data=DFR2_LF)
summary(AdjMod_LF2)
AdjMod_LF2_Stats <- data.frame(tidy(AdjMod_LF2))
colnames(AdjMod_LF2_Stats) <- c('Variable', 'Coefficient', 'std error', 't_stat', 'p_value')
AdjMod_LF2_Stats <- AdjMod_LF2_Stats[order(AdjMod_LF2_Stats$p_value),]
AdjMod_LF2_Stats <- round_df(AdjMod_LF2_Stats, digits = 3)

#leap Backwards
# Set seed for reproducibility
set.seed(123)

# Train the model
Mod_LB <- train(Wheat_ton_ha ~ ., data=DFR2,
                method = 'leapBackward', 
                tuneGrid = data.frame(nvmax = 1:6),
                trControl = train.control)

Model_STATS_LB <- data.frame(Mod_LB$results)

#determine the best variables
var <- Mod_LB$bestTune
var
Coef_LB <- data.frame(coef(Mod_LB$finalModel, var$nvmax))
Coef_LB$Feature <- rownames(Coef_LB)
Coef_LB <- Coef_LB[,c(2,1)]
rownames(Coef_LB) <- c()
colnames(Coef_LB)[2] <- 'Coefficient'

#make model with these coefs
Coef_LB <- subset(Coef_LB, Feature !='(Intercept)')
Coef_LB[nrow(Coef_LB)+1,] <- c('Wheat_ton_ha', NA)
DFR2_LB <- DFR2[Coef_LB$Feature]

#make model as a function of these parameters
AllPrecipMod_LB <- lm(Wheat_ton_ha~., data=DFR2_LB)
summary(AllPrecipMod_LB)


#make model as a function of these parameters
AdjMod_LB2 <- lm(Wheat_ton_ha~., data=DFR2_LB)
summary(AdjMod_LB2)
AdjMod_LB2_Stats <- data.frame(tidy(AdjMod_LB2))
colnames(AdjMod_LB2_Stats) <- c('Variable', 'Coefficient', 'std error', 't_stat', 'p_value')
AdjMod_LB2_Stats <- AdjMod_LB2_Stats[order(AdjMod_LB2_Stats$p_value),]
AdjMod_LB2_Stats <- round_df(AdjMod_LB2_Stats, digits = 3)

#BAsic step function no CV
## Full model
mod.1 <- lm(Wheat_ton_ha ~ ., data=DFR2)
## Null model
mod.0 <- lm(Wheat_ton_ha ~ 1, data=DFR2)
mod.Final <- step(mod.0, scope = formula(mod.1))
summary(mod.Final)
AdjMod2_SF_Stats <- data.frame(tidy(mod.Final))
colnames(AdjMod2_SF_Stats) <- c('Variable', 'Coefficient', 'std error', 't-stat', 'p_value')
AdjMod2_SF_Stats <- AdjMod2_SF_Stats[order(AdjMod2_SF_Stats$p_value),]
AdjMod2_SF_Stats <- round_df(AdjMod2_SF_Stats, digits = 3)




#Save All Precipitation Data
list_of_datasets <- list("Model LB" = Model_STATS_LB, "Model_Stats_LB" = AdjMod_LB2_Stats,
                         "Model LF" = Model_STATS_LF, "Model_Stats_LF" = AdjMod_LF2_Stats,
                         'Adj_Model2_Stats' = AdjMod2_SF_Stats)
write.xlsx(list_of_datasets, file = "C:/Users/Ryan/Box/NASA_WEF/output/Cat_R2/PrecipDFR2.xlsx")






#Leaps
#Precip, mmhr , R3
#leap Forward
# Set seed for reproducibility
set.seed(123)
# Set up repeated 10 k-fold cross-validation
#This method tunes model based on reducing RMSE
train.control <- trainControl(method = "cv", number = 5)
# Train the model
#methods <- c('leapBackward','leapForward','leapSeq' )
Mod_LF <- train(Wheat_ton_ha ~ ., data=DFR3,
                method = 'leapForward', 
                tuneGrid = data.frame(nvmax = 1:6),
                trControl = train.control)

Model_STATS_LF <- data.frame(Mod_LF$results)

#determine the best variables
var <- Mod_LF$bestTune
var
Coef_LF <- data.frame(coef(Mod_LF$finalModel, var$nvmax))
Coef_LF$Feature <- rownames(Coef_LF)
Coef_LF <- Coef_LF[,c(2,1)]
rownames(Coef_LF) <- c()
colnames(Coef_LF)[2] <- 'Coefficient'

#make model with these coefs
Coef_LF <- subset(Coef_LF, Feature !='(Intercept)')
Coef_LF[nrow(Coef_LF)+1,] <- c('Wheat_ton_ha', NA)
DFR3_LF <- DFR3[Coef_LF$Feature]


#make model as a function of these parameters
AdjMod_LF2 <- lm(Wheat_ton_ha~., data=DFR3_LF)
summary(AdjMod_LF2)
AdjMod_LF2_Stats <- data.frame(tidy(AdjMod_LF2))
colnames(AdjMod_LF2_Stats) <- c('Variable', 'Coefficient', 'std error', 't_stat', 'p_value')
AdjMod_LF2_Stats <- AdjMod_LF2_Stats[order(AdjMod_LF2_Stats$p_value),]
AdjMod_LF2_Stats <- round_df(AdjMod_LF2_Stats, digits = 3)

#leap Backwards
# Set seed for reproducibility
set.seed(123)

# Train the model
Mod_LB <- train(Wheat_ton_ha ~ ., data=DFR3,
                method = 'leapBackward', 
                tuneGrid = data.frame(nvmax = 1:6),
                trControl = train.control)

Model_STATS_LB <- data.frame(Mod_LB$results)

#determine the best variables
var <- Mod_LB$bestTune
var
Coef_LB <- data.frame(coef(Mod_LB$finalModel, var$nvmax))
Coef_LB$Feature <- rownames(Coef_LB)
Coef_LB <- Coef_LB[,c(2,1)]
rownames(Coef_LB) <- c()
colnames(Coef_LB)[2] <- 'Coefficient'

#make model with these coefs
Coef_LB <- subset(Coef_LB, Feature !='(Intercept)')
Coef_LB[nrow(Coef_LB)+1,] <- c('Wheat_ton_ha', NA)
DFR3_LB <- DFR3[Coef_LB$Feature]

#make model as a function of these parameters
AllPrecipMod_LB <- lm(Wheat_ton_ha~., data=DFR3_LB)
summary(AllPrecipMod_LB)


#make model as a function of these parameters
AdjMod_LB2 <- lm(Wheat_ton_ha~., data=DFR3_LB)
summary(AdjMod_LB2)
AdjMod_LB2_Stats <- data.frame(tidy(AdjMod_LB2))
colnames(AdjMod_LB2_Stats) <- c('Variable', 'Coefficient', 'std error', 't_stat', 'p_value')
AdjMod_LB2_Stats <- AdjMod_LB2_Stats[order(AdjMod_LB2_Stats$p_value),]
AdjMod_LB2_Stats <- round_df(AdjMod_LB2_Stats, digits = 3)

#BAsic step function no CV
## Full model
mod.1 <- lm(Wheat_ton_ha ~ ., data=DFR3)
## Null model
mod.0 <- lm(Wheat_ton_ha ~ 1, data=DFR3)
mod.Final <- step(mod.0, scope = formula(mod.1))
summary(mod.Final)
AdjMod2_SF_Stats <- data.frame(tidy(mod.Final))
colnames(AdjMod2_SF_Stats) <- c('Variable', 'Coefficient', 'std error', 't-stat', 'p_value')
AdjMod2_SF_Stats <- AdjMod2_SF_Stats[order(AdjMod2_SF_Stats$p_value),]
AdjMod2_SF_Stats <- round_df(AdjMod2_SF_Stats, digits = 3)




#Save All Precipitation Data
list_of_datasets <- list("Model LB" = Model_STATS_LB, "Model_Stats_LB" = AdjMod_LB2_Stats,
                         "Model LF" = Model_STATS_LF, "Model_Stats_LF" = AdjMod_LF2_Stats,
                         'Adj_Model2_Stats' = AdjMod2_SF_Stats)
write.xlsx(list_of_datasets, file = "C:/Users/Ryan/Box/NASA_WEF/output/Cat_R2/PrecipDFR3.xlsx")







#Leaps
#Precip, mmhr and hours rem, R4
#leap Forward
# Set seed for reproducibility
set.seed(123)
# Set up repeated 10 k-fold cross-validation
#This method tunes model based on reducing RMSE
train.control <- trainControl(method = "cv", number = 5)
# Train the model
#methods <- c('leapBackward','leapForward','leapSeq' )
Mod_LF <- train(Wheat_ton_ha ~ ., data=DFR4,
                method = 'leapForward', 
                tuneGrid = data.frame(nvmax = 1:6),
                trControl = train.control)

Model_STATS_LF <- data.frame(Mod_LF$results)

#determine the best variables
var <- Mod_LF$bestTune
var
Coef_LF <- data.frame(coef(Mod_LF$finalModel, var$nvmax))
Coef_LF$Feature <- rownames(Coef_LF)
Coef_LF <- Coef_LF[,c(2,1)]
rownames(Coef_LF) <- c()
colnames(Coef_LF)[2] <- 'Coefficient'

#make model with these coefs
Coef_LF <- subset(Coef_LF, Feature !='(Intercept)')
Coef_LF[nrow(Coef_LF)+1,] <- c('Wheat_ton_ha', NA)
DFR4_LF <- DFR4[Coef_LF$Feature]


#make model as a function of these parameters
AdjMod_LF2 <- lm(Wheat_ton_ha~., data=DFR4_LF)
summary(AdjMod_LF2)
AdjMod_LF2_Stats <- data.frame(tidy(AdjMod_LF2))
colnames(AdjMod_LF2_Stats) <- c('Variable', 'Coefficient', 'std error', 't_stat', 'p_value')
AdjMod_LF2_Stats <- AdjMod_LF2_Stats[order(AdjMod_LF2_Stats$p_value),]
AdjMod_LF2_Stats <- round_df(AdjMod_LF2_Stats, digits = 3)

#leap Backwards
# Set seed for reproducibility
set.seed(123)

# Train the model
Mod_LB <- train(Wheat_ton_ha ~ ., data=DFR4,
                method = 'leapBackward', 
                tuneGrid = data.frame(nvmax = 1:6),
                trControl = train.control)

Model_STATS_LB <- data.frame(Mod_LB$results)

#determine the best variables
var <- Mod_LB$bestTune
var
Coef_LB <- data.frame(coef(Mod_LB$finalModel, var$nvmax))
Coef_LB$Feature <- rownames(Coef_LB)
Coef_LB <- Coef_LB[,c(2,1)]
rownames(Coef_LB) <- c()
colnames(Coef_LB)[2] <- 'Coefficient'

#make model with these coefs
Coef_LB <- subset(Coef_LB, Feature !='(Intercept)')
Coef_LB[nrow(Coef_LB)+1,] <- c('Wheat_ton_ha', NA)
DFR4_LB <- DFR4[Coef_LB$Feature]

#make model as a function of these parameters
AllPrecipMod_LB <- lm(Wheat_ton_ha~., data=DFR4_LB)
summary(AllPrecipMod_LB)


#make model as a function of these parameters
AdjMod_LB2 <- lm(Wheat_ton_ha~., data=DFR4_LB)
summary(AdjMod_LB2)
AdjMod_LB2_Stats <- data.frame(tidy(AdjMod_LB2))
colnames(AdjMod_LB2_Stats) <- c('Variable', 'Coefficient', 'std error', 't_stat', 'p_value')
AdjMod_LB2_Stats <- AdjMod_LB2_Stats[order(AdjMod_LB2_Stats$p_value),]
AdjMod_LB2_Stats <- round_df(AdjMod_LB2_Stats, digits = 3)

#BAsic step function no CV
## Full model
mod.1 <- lm(Wheat_ton_ha ~ ., data=DFR4)
## Null model
mod.0 <- lm(Wheat_ton_ha ~ 1, data=DFR4)
mod.Final <- step(mod.0, scope = formula(mod.1))
summary(mod.Final)
AdjMod2_SF_Stats <- data.frame(tidy(mod.Final))
colnames(AdjMod2_SF_Stats) <- c('Variable', 'Coefficient', 'std error', 't-stat', 'p_value')
AdjMod2_SF_Stats <- AdjMod2_SF_Stats[order(AdjMod2_SF_Stats$p_value),]
AdjMod2_SF_Stats <- round_df(AdjMod2_SF_Stats, digits = 3)




#Save All Precipitation Data
list_of_datasets <- list("Model LB" = Model_STATS_LB, "Model_Stats_LB" = AdjMod_LB2_Stats,
                         "Model LF" = Model_STATS_LF, "Model_Stats_LF" = AdjMod_LF2_Stats,
                         'Adj_Model2_Stats' = AdjMod2_SF_Stats)
write.xlsx(list_of_datasets, file = "C:/Users/Ryan/Box/NASA_WEF/output/Cat_R2/PrecipDFR4.xlsx")














#predict with the model
testing$wheat_pred <- predict(mod.Final, newdata=testing )
testing$Percerror <- ((testing$wheat_pred-testing$Wheat_ton_ha)/testing$Wheat_ton_ha)*100
testing$absPercerror <- abs(testing$Percerror)
mean(testing$absPercerror)


#Plot
plot(testing$Wheat_ton_ha, type="l", col="green", xlab="Index", ylab="Wheat ton/ha")
lines(testing$wheat_pred, col="red", lwd=2)
title("Linear Regression models")
legend(2,1,c("Obseved","Predicted"), lwd=c(5,2), col=c("green","red"), y.intersp=1.5)




















anova(mod.Final, mod.Finalmmhr_hrRem, mod.FinalmmhrRem)



#comparing different model packages
#Even though Final Join had the best predictive capability, it was 'not significant'. However we 
#dont really care if a variable is significant if it improves predictive performance, thus trying
#OLSRR package
#model <- Wheat_ton_ha~.
#fit <- lm(model, DF)
#ols_step_both_p(fit, pent = 0.1, prem = 0.3, details = TRUE)



#look at MLR package, send email for code on MLR
nfeatures = dim(Features)

xvid = sample(1:4, size = 68, replace=TRUE)

mse = rep(NA, 4)
for (i in 1:4) {
  training = Features[xvid != i,]
  testing = Features[xvid == i,]
  
  ## build model and test
  mse[i] <- nmse
}
}
