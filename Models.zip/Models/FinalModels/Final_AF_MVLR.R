#Developing Metrics GSL
#must run JordanRiverDataProcessing_Annual or JordanRiverDataProcessing_Annual_rem
library(dataRetrieval)
library(xts)
library(timeDate)
library(lubridate)
library(ggplot2)
library(raster)
library(rgdal)
library(sf)
library(maptools)
library(mapproj)
library(maps)
library(sp)
library(RColorBrewer)
library(viridis)
library(viridisLite)
library(rasterVis)
library(chron)
library(lattice)
library(ncdf4)
library(rgeos)
library(gridExtra)
library(PBSmapping)
library(readxl)
library(grid)
library(gridExtra)
library(grid)
library(ggplot2)
library(lattice)
library(tidyverse)
library(cowplot)
library(forecast)
library(vars)
library(MLmetrics)
library(tidyverse)
library(heatwaveR)
library(data.table)
library(ggpubr)
library(data.table)

#rounding function
round_df <- function(df, digits) {
  nums <- vapply(df, is.numeric, FUN.VALUE = logical(1))
  
  df[,nums] <- round(df[,nums], digits = digits)
  
  (df)
}

#exploring MARS
#upload data
Potohar_Wheat <- read_excel('C:/Users/Ryan/Box/NASA_WEF/data/Features/Potohar_HR_Features.xlsx')
Potohar_Wheat$Ln_Wheat <- NULL


#Set train data the same as other python models, WK_14_Minweekly_SM_0_10cm
rem1 <- read.csv('C:/Users/Ryan/Box/NASA_WEF/output/V2/RF/Season_Week_Month_top5/DataWithPredictedValues.csv')
rem1 <- rem1$WK_14_Minweekly_SM_0_10cm

#Potohar training datat
Potohar_Wheat_train <- subset(Potohar_Wheat, !WK_14_Minweekly_SM_0_10cm %in% rem1)
Potohar_Wheat_test <- subset(Potohar_Wheat, WK_14_Minweekly_SM_0_10cm %in% rem1)


#Make a dataframe of step models first____ features
FeaturesSF <- c( 'WK_14_Minweekly_C','WK_15_Meanweekly_SM_0_10cm', 'JanandMar_below8mmhr', 
                 'MinMonth_Season_STemp_0_10cm',  'Wheat_ton_ha')

Features_RF <- c( 'WK_14_Minweekly_SM_0_10cm','WK_15_Minweekly_SM_0_10cm','WK_16_Minweekly_SM_0_10cm',
                  'WK_13_Maxweekly_SM_0_10cm', 'WK_14_weekly_STemp_Hrsabove_10C','WK_24_weekly_STemp_Hrsabove_10C',
                  'WK_16_weekly_STemp_Hrsabove_10C', 'Feb_Minmonthly_SM_0_10cm','Jan_Maxmonthly_SM_10_40cm',
                  'MaxMonth_Season_Precip_mm','Season_Summonthly_Precip_mm',
                  'Wheat_ton_ha')
#Take top features from categories top performing models
Features_MARS <- c('WK_11_Minweekly_C','WK_14_Minweekly_C','WK_15_Minweekly_C',
                   'WK_10_Maxweekly_C',
                   'WK_23_Maxweekly_C','MaxMonth_Season_Precip_mm',
                   'Feb_Meanmonthly_SM_0_10cm','WK_23_Minweekly_STemp_0_10cm',
                   'Wheat_ton_ha')

#make a final features dataframe and save for further analysis
All_Features <- c('WK_11_Minweekly_C','WK_14_Minweekly_C','WK_15_Minweekly_C',
                  'WK_10_Maxweekly_C',
                  'WK_23_Maxweekly_C','MaxMonth_Season_Precip_mm',
                  'Feb_Meanmonthly_SM_0_10cm','WK_23_Minweekly_STemp_0_10cm',
                  'Wheat_ton_ha','WK_14_Minweekly_SM_0_10cm','WK_15_Minweekly_SM_0_10cm','WK_16_Minweekly_SM_0_10cm',
                  'WK_13_Maxweekly_SM_0_10cm', 'WK_14_weekly_STemp_Hrsabove_10C','WK_24_weekly_STemp_Hrsabove_10C',
                  'WK_16_weekly_STemp_Hrsabove_10C', 'Feb_Minmonthly_SM_0_10cm','Jan_Maxmonthly_SM_10_40cm',
                  'MaxMonth_Season_Precip_mm','Season_Summonthly_Precip_mm',
                  'Wheat_ton_ha','WK_14_Minweekly_C','WK_15_Meanweekly_SM_0_10cm', 'JanandMar_below8mmhr', 
                  'MinMonth_Season_STemp_0_10cm',  'Wheat_ton_ha')
All_Features <- Potohar_Wheat[All_Features]
All_Features <- All_Features[,!duplicated(colnames(All_Features))]
All_Features <- All_Features[,order(colnames(All_Features))]
All_Features$MinMonth_Season_STemp_0_10cm
write.xlsx(All_Features,'C:/Users/Ryan/Box/NASA_WEF/output/Final/RFR/Final_FeaturesAll.xlsx')

DF_SF_train <- Potohar_Wheat_train[FeaturesSF]
DF_SF_test <- Potohar_Wheat_test[FeaturesSF]

DF_RF_train <- Potohar_Wheat_train[Features_RF]
DF_RF_test <- Potohar_Wheat_test[Features_RF]

DF_MARS_train <- Potohar_Wheat_train[Features_MARS]
DF_MARS_test <- Potohar_Wheat_test[Features_MARS]


#models
SF_Mod <- lm(Wheat_ton_ha ~ ., data=DF_SF_train)
RF_Mod <- lm(Wheat_ton_ha ~ ., data=DF_RF_train)
MARS_Mod <- lm(Wheat_ton_ha ~ ., data=DF_MARS_train)

#create a prediction dataset
DF_SF_test$SF_Pred <- predict(SF_Mod, DF_SF_test)
DF_RF_test$RF_Pred <- predict(RF_Mod, DF_RF_test)
DF_MARS_test$MARS_Pred <- predict(MARS_Mod, DF_MARS_test)

#sort data to make nice figure
DF_SF_test <- DF_SF_test[order(DF_SF_test$Wheat_ton_ha),]
DF_RF_test <- DF_RF_test[order(DF_RF_test$Wheat_ton_ha),]
DF_MARS_test <- DF_MARS_test[order(DF_MARS_test$Wheat_ton_ha),]

#coefs
summary(RF_Mod)
summary(SF_Mod)
summary(MARS_Mod)




#make one dataframe that has both
Results <- cbind(DF_SF_test, DF_RF_test, DF_MARS_test)
Results <- Results[, !duplicated(colnames(Results))]
Results <- Results[, c(1:4, 7:18, 5,6,19,29)]
setDT(Results, keep.rownames=TRUE)[]
Results$rn <- as.numeric(Results$rn)

#Find some stats components
cor(Results$MARS_Pred, Results$Wheat_ton_ha)^2
cor(Results$RF_Pred, Results$Wheat_ton_ha)^2
cor(Results$SF_Pred, Results$Wheat_ton_ha)^2

#mAPE
mean(abs((Results$MARS_Pred-Results$Wheat_ton_ha)/Results$Wheat_ton_ha))*100
mean(abs((Results$RF_Pred-Results$Wheat_ton_ha)/Results$Wheat_ton_ha))*100
mean(abs((Results$SF_Pred-Results$Wheat_ton_ha)/Results$Wheat_ton_ha))*100


#RMSE
RMSE(Results$MARS_Pred,Results$Wheat_ton_ha)
RMSE(Results$RF_Pred,Results$Wheat_ton_ha)
RMSE(Results$SF_Pred,Results$Wheat_ton_ha)





#redo with scatter points and loes line
legend_title <- "Model Component Input From:"
maxwheat <- max(Results$Wheat_ton_ha, Results$SF_Pred)
maxwheat <- round(1.1*max(maxwheat, Results$RF_Pred),1)
maxwheat

windows(width = 11, height = 7)
MVLRmodels <- ggplot(data=Results, aes(rn)) +
  geom_smooth(aes(y=(MARS_Pred), colour = "MARS Components"), size = 1.5,
              method = 'loess', span = 0.6, level = 0.95, fill = 'turquoise4', 
              alpha=0.2, linetype = 'dotted')+ 
  geom_point(aes(y=(MARS_Pred), colour = "MARS Components"), size = 2 )+ 
  geom_line(aes(y=(Wheat_ton_ha), colour = "Observed"),linetype = 'dashed', size = 1.5)+ 
  geom_smooth(aes(y=(RF_Pred), colour = "RF Components"), size = 1.5,
              method = 'loess', span = 0.6, level = 0.95, fill = 'red2',
              alpha=0.2, linetype = 'dotted', size = 2)+ 
  geom_point(aes(y=(RF_Pred), colour = "RF Components"), size = 2 )+ 
  geom_smooth(aes(y=(SF_Pred), colour = "StepWise Components"), size = 1.5,
              method = 'loess', span = 0.6,level = 0.95, fill = 'darkorange2',
              alpha=0.2, linetype = 'dotted', size = 2)+ 
  geom_point(aes(y=(SF_Pred), colour = "StepWise Components"), size = 2 )+ 
  scale_color_manual( legend_title,values = c('turquoise4', "blue1","red2", 'darkorange2'))+
  xlab("Observation (Of Increasing Yield) ")+
  ylab("Predicted Wheat Yield (tones/hectare)")+
  scale_y_continuous(breaks = seq(0,maxwheat, 0.25), limits = c(0,maxwheat))+
  theme(plot.title = element_text(hjust = 0.5))+
  ggtitle(paste(" "))+
  theme_classic()+
  theme(plot.title = element_text(hjust = 0.5, size = 20),
        axis.line.x = element_line(color="black", size = 0.9),
        axis.line.y = element_line(color="black", size = 0.9),
        axis.text = element_text(size = 16),
        axis.title = element_text(size = 16),
        legend.position = 'none')+
  annotate('text', x=c(9.6,9.4,9.4), y=c(0.2,0.1,0.0), 
           label = c('MARS MAPE = 9.7%' ,'RF MAPE = 14.3%', 'SW MAPE = 9.9%'),
           size = 4)+
  annotate('text', x=c(12.6,12.45,12.5), y=c(0.2,0.1,0.0), 
           label = c('MARS RMSE = 0.16', 'RF RMSE = 0.22', 'SW RMSE = 0.18'),
           size = 4)+
  annotate('text', x=c(15.65,15.45,15.5), y=c(0.2,0.1,0.0), 
           label = c('MARS NSC = 0.85', 'RF NSC = 0.72', 'SW NSC = 0.82'),
           size = 4)
MVLRmodels


#Predicted vs observed
maxobs <- round(1.1*max(Results$Wheat_ton_ha),1)
minobs <- round(0.9*min(Results$Wheat_ton_ha),1)
minresults <- round(0.9*min(Results$SF_Pred, Results$RF_Pred),1)

windows(width = 7, height = 7)
MVLRmodels2 <- ggplot(data=Results, aes(Wheat_ton_ha)) +
  geom_point(aes(y=(MARS_Pred), colour = "MARS Components"), size = 2)+ 
  geom_line(aes(y=(Wheat_ton_ha), colour = "Observed"),linetype = 'dashed', size = 0.5)+ 
  geom_point(aes(y=(RF_Pred), colour = "RF Components"), size = 2)+ 
  geom_point(aes(y=(SF_Pred), colour = "StepWise Components"), size = 2)+ 
  scale_color_manual( legend_title,values = c('turquoise4', 'blue1', 'red2', "darkorange2"))+
  xlab("Observed (tones/hectare)")+
  ylab(" ")+
  scale_y_continuous(breaks = seq(0,maxwheat, 0.25), limits = c(minresults,maxwheat))+
  scale_x_continuous(breaks = seq(0,maxobs,0.25), limits = c(minobs, maxobs))+
  theme(plot.title = element_text(hjust = 0.5))+
  ggtitle(paste(""))+
  theme_classic()+
  theme(plot.title = element_text(hjust = 0.5),
        axis.line.x = element_line(color="black", size = 0.9),
        axis.line.y = element_line(color="black", size = 0.9),
        axis.text = element_text(size = 16),
        axis.title = element_text(size = 16),
        legend.position = c(.8,.15),
        legend.title = element_text(size = 13),
        legend.text = element_text(size= 12))
MVLRmodels2


#put into one figure
windows(width = 18, height = 9)
MVLR <- ggarrange(MVLRmodels,
                  MVLRmodels2,
                  ncol=2, nrow=1,
                  widths = c(1.5,1))
MVLR



#put  into one figure
title <- ggdraw() + draw_label("MARS, Stepwise, and Random Forest Components Linear Regression Model Performance", 
                               fontface='bold', size = 18)
#put traditional together
windows(width = 18, height = 9)
Fig <- plot_grid(
  title,
  MVLR,
  align = "v", 
  nrow = 2,
  ncol = 1,
  rel_widths = c(1,1),
  rel_heights = c(0.2,1))
Fig



