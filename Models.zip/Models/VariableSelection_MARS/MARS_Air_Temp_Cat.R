#Potohar district data analysis
#might have to run other distrits analysis
library(dataRetrieval)
library(xts)
library(timeDate)
library(lubridate)
library(ggplot2)
library(raster)
library(rgdal)
library(sf)
library(maptools)
library(mapproj)
library(maps)
library(sp)
library(RColorBrewer)
library(viridis)
library(viridisLite)
library(rasterVis)
library(chron)
library(lPotice)
library(ncdf4)
library(rgeos)
library(gridExtra)
library(PBSmapping)
library(na.tools)
library(readxl)
library(writexl)
library(corrplot)
library(dplyr)
library(clusterSim)
library(tidyr)
library(rsample)   # data splitting 
library(ggplot2)   # plotting
library(earth)     # fit MARS models
library(caret)     # automating the tuning process
library(vip)       # variable importance
library(pdp) 
library(caTools)
library(MLmetrics)
library(olsrr)
library(MASS)
library(leaps)
library(openxlsx)
library(broom)
library(data.table)


#rounding function
round_df <- function(df, digits) {
  nums <- vapply(df, is.numeric, FUN.VALUE = logical(1))
  
  df[,nums] <- round(df[,nums], digits = digits)
  
  (df)
}

#exploring MARS
#upload data
Potohar_Wheat <- read_excel('C:/Users/Ryan/Box/NASA_WEF/data/Features/Potohar_HR_Features.xlsx')
Potohar_Wheat$Ln_Wheat <- NULL


#load the best Air Temp models, ATDFR2SW and ATDFR2SW
ATDFR1SW <- read_excel('C:/Users/Ryan/Box/NASA_WEF/output/Cat_R2/AirTempDFR1.xlsx', sheet = 'Model_AdjMod_SF_Stats')
ATDFR2SW <- read_excel('C:/Users/Ryan/Box/NASA_WEF/output/Cat_R2/AirTempDFR2.xlsx', sheet = 'Model_AdjMod_SF_Stats')


#remove intercept value
ATDFR1SW <- ATDFR1SW[!grepl('(Intercept)', ATDFR1SW$Variable),]
ATDFR2SW <- ATDFR2SW[!grepl('(Intercept)', ATDFR2SW$Variable),]

#designate feature groups as the AT variables
FeaturesR1 <- ATDFR1SW$Variable
FeaturesR2 <- ATDFR2SW$Variable
#building model with just top 20 most correlcated features
DFR1 <- Potohar_Wheat[FeaturesR1]
DFR2 <- Potohar_Wheat[FeaturesR2]

#need to add in wheat
DFR1$Wheat_ton_ha <- Potohar_Wheat$Wheat_ton_ha
DFR2$Wheat_ton_ha <- Potohar_Wheat$Wheat_ton_ha


#DFR1
#set test/train data
set.seed(123)
DFR1$Sample <- sample.split(DFR1$Wheat_ton_ha, SplitRatio = .80)
trainingDFR1 <- subset(DFR1, DFR1$Sample==TRUE)
testingDFR1 <- subset(DFR1, DFR1$Sample==FALSE)

#remove unnecessary columns
trainingDFR1$Sample <- NULL
testingDFR1$Sample <- NULL

#order the test data
testingDFR1 <- testingDFR1[order(testingDFR1$Wheat_ton_ha),]


#DFR2
#set test/train data
set.seed(123)
DFR2$Sample <- sample.split(DFR2$Wheat_ton_ha, SplitRatio = .80)
trainingDFR2 <- subset(DFR2, DFR2$Sample==TRUE)
testingDFR2 <- subset(DFR2, DFR2$Sample==FALSE)

#remove unnecessary columns
trainingDFR2$Sample <- NULL
testingDFR2$Sample <- NULL

#order the test data
testingDFR2 <- testingDFR2[order(testingDFR2$Wheat_ton_ha),]






#Set test/train data the same as other python models, WK_14_Minweekly_C
rem <- round(c(6.424,3.376,2.054,-0.343,8.658,6.679,8.22,0.986,
         8.371,4.735,9.932,8.241,5.28,3.706,7.091,5.771,7.013),3)
#DFR1
DFR1$WK_14_Minweekly_C <- round(DFR1$WK_14_Minweekly_C, 3)
trainingDFR1P <- subset(DFR1, !WK_14_Minweekly_C %in% rem)
testingDFR1P <- subset(DFR1, WK_14_Minweekly_C %in% rem)

#DFR2
DFR2$WK_14_Minweekly_C <- round(DFR2$WK_14_Minweekly_C, 3)
trainingDFR2P <- subset(DFR2, !WK_14_Minweekly_C %in% rem)
testingDFR2P <- subset(DFR2, WK_14_Minweekly_C %in% rem)

#remove unnecessary columns
#trainingDF1$Sample <- NULL
#testingDF1$Sample <- NULL

#order the test data
#testingDF1 <- testingDF1[order(testingDF1$Wheat_ton_ha),]

#make a MARS model to fit DF1, top correlated Air temp values
mod.DF1 <- earth(Wheat_ton_ha~.,data=trainingDFR1, degree = 1)
print(mod.DF1)
summary(mod.DF1) %>% .$coefficients
plot(mod.DF1, which = 1)




#using DFR1 and random seed in R
# create a tuning grid
hyper_grid <- expand.grid(
  degree = 1:3, 
  nprune = seq(2, 100, length.out = 10) %>% floor()
)
head(hyper_grid)

# for reproducibiity
set.seed(123)
# cross validated model
tuned_DFR1 <- train(
  x = subset(trainingDFR1, select = -Wheat_ton_ha),
  y = trainingDFR1$Wheat_ton_ha,
  method = "earth",
  metric = "RMSE",
  trControl = trainControl(method = "cv", number = 10),
  tuneGrid = hyper_grid
  
)
plot(tuned_DFR1, which = 1)
# best model
tuned_DFR1$bestTune
##    nprune degree
## 2     12      2

#set tuned model as best tune
tuned_DFR1$finalModel
summary(tuned_DFR1)



tunedDFR1cof <- data.frame(summary(tuned_DFR1) %>% .$coefficients)
tunedDFR1cof$Parameter_Threshold <- rownames(tunedDFR1cof)
rownames(tunedDFR1cof) <- NULL
tunedDFR1cof <- tunedDFR1cof[,c(2,1)]
colnames(tunedDFR1cof)[2] <- 'Coefficient'


# plot results
ggplot(tuned_DFR1)

# variable importance plots
p1 <- vip(tuned_DFR1, num_features = 40, bar = FALSE, value = "gcv") + ggtitle("GCV")
p2 <- vip(tuned_DFR1, num_features = 40, bar = FALSE, value = "rss") + ggtitle("RSS")

gridExtra::grid.arrange(p1, p2, ncol = 2)

#find Thresholds and dependencies
p3 <- partial(tuned_DFR1, pred.var = "WK_14_Minweekly_C", grid.resolution = 10) %>% autoplot()
p4 <- partial(tuned_DFR1, pred.var = "Jan_Medianmonthly_C", grid.resolution = 10) %>% autoplot()
p5 <- partial(tuned_DFR1, pred.var = "Season_Precip_MeanAirTemp", grid.resolution = 10) %>% autoplot()
#p6 <- partial(tuned_DFR1, pred.var = c("WK_14_Minweekly_C", "Season_Precip_MeanAirTemp"), grid.resolution = 10) %>% 
 # plotPartial(levelplot = FALSE, zlab = "yhat", drape = TRUE, colorkey = TRUE, screen = list(z = -20, x = -60))

dev.new(width = 900, height = 330, unit = "px")
gridExtra::grid.arrange(p3, p4, p5, nrow = 1, ncol = 3)







#DRF1 Pythond data
# for reproducibiity
set.seed(123)
# cross validated model
tuned_DFR1P <- train(
  x = subset(trainingDFR1P, select = -Wheat_ton_ha),
  y = trainingDFR1P$Wheat_ton_ha,
  method = "earth",
  metric = "RMSE",
  trControl = trainControl(method = "cv", number = 10),
  tuneGrid = hyper_grid
  
)

# best model
tuned_DFR1P$bestTune
##    nprune degree
## 2     12      1

#set tuned model as best tune
tuned_DFR1P$finalModel
summary(tuned_DFR1P)
tunedDFR1Pcof <- data.frame(summary(tuned_DFR1P) %>% .$coefficients)
tunedDFR1Pcof$Parameter_Threshold <- rownames(tunedDFR1Pcof)
rownames(tunedDFR1Pcof) <- NULL
tunedDFR1Pcof <- tunedDFR1Pcof[,c(2,1)]
colnames(tunedDFR1Pcof)[2] <- 'Coefficient'


# plot results
ggplot(tuned_DFR1P)

# variable importance plots
p1 <- vip(tuned_DFR1P, num_features = 40, bar = FALSE, value = "gcv") + ggtitle("GCV")
p2 <- vip(tuned_DFR1P, num_features = 40, bar = FALSE, value = "rss") + ggtitle("RSS")

gridExtra::grid.arrange(p1, p2, ncol = 2)

#find Thresholds and dependencies
p3 <- partial(tuned_DFR1P, pred.var = "WK_14_Minweekly_C", grid.resolution = 10) %>% autoplot()
p4 <- partial(tuned_DFR1P, pred.var = "Jan_Medianmonthly_C", grid.resolution = 10) %>% autoplot()
p5 <- partial(tuned_DFR1P, pred.var = "Season_Precip_MeanAirTemp", grid.resolution = 10) %>% autoplot()
#p6 <- partial(tuned_DFR1, pred.var = c("WK_14_Minweekly_C", "Season_Precip_MeanAirTemp"), grid.resolution = 10) %>% 
# plotPartial(levelplot = FALSE, zlab = "yhat", drape = TRUE, colorkey = TRUE, screen = list(z = -20, x = -60))

dev.new(width = 900, height = 330, unit = "px")
gridExtra::grid.arrange(p3, p4, p5, nrow = 1, ncol = 3)






#DFR2
# create a tuning grid
hyper_grid <- expand.grid(
  degree = 1:3, 
  nprune = seq(2, 100, length.out = 10) %>% floor()
)
head(hyper_grid)

# for reproducibiity
set.seed(123)
# cross validated model
tuned_DFR2 <- train(
  x = subset(trainingDFR2, select = -Wheat_ton_ha),
  y = trainingDFR2$Wheat_ton_ha,
  method = "earth",
  metric = "RMSE",
  trControl = trainControl(method = "cv", number = 5),
  tuneGrid = hyper_grid
)

# best model
tuned_DFR2$bestTune
##    nprune degree
## 2     2      2

#set tuned model as best tune
tuned_DFR2$finalModel
summary(tuned_DFR2)
tuned_DFR2$selected.terms
summary(tuned_DFR2) %>% .$coefficients
# plot results
ggplot(tuned_DFR2)

# variable importance plots
p1 <- vip(tuned_DFR2, num_features = 40, bar = FALSE, value = "gcv") + ggtitle("GCV")
p2 <- vip(tuned_DFR2, num_features = 40, bar = FALSE, value = "rss") + ggtitle("RSS")

gridExtra::grid.arrange(p1, p2, ncol = 2)

#find Thresholds and dependencies
p10 <- partial(tuned_DFR2, pred.var = "WK_14_Minweekly_C", grid.resolution = 10) %>% autoplot()
p10
gridExtra::grid.arrange(p3, p4, p5,p6,p7,p8,p9, nrow = 3, ncol = 3)







#DFR2, using same data as in Python models
# create a tuning grid
hyper_grid <- expand.grid(
  degree = 1:3, 
  nprune = seq(2, 100, length.out = 10) %>% floor()
)
head(hyper_grid)

# for reproducibiity
set.seed(123)
# cross validated model
tuned_DFR2P <- train(
  x = subset(trainingDFR2P, select = -Wheat_ton_ha),
  y = trainingDFR2P$Wheat_ton_ha,
  method = "earth",
  metric = "RMSE",
  trControl = trainControl(method = "cv", number = 5),
  tuneGrid = hyper_grid
)

# best model
tuned_DFR2P$bestTune
##    nprune degree
## 2     2      2

#set tuned model as best tune
tuned_DFR2P$finalModel
summary(tuned_DFR2P)
tuned_DFR2P$selected.terms
summary(tuned_DFR2P) %>% .$coefficients
# plot results
ggplot(tuned_DFR2P)

# variable importance plots
p1 <- vip(tuned_DFR2P, num_features = 40, bar = FALSE, value = "gcv") + ggtitle("GCV")
p2 <- vip(tuned_DFR2P, num_features = 40, bar = FALSE, value = "rss") + ggtitle("RSS")

gridExtra::grid.arrange(p1, p2, ncol = 2)

#find Thresholds and dependencies
p10 <- partial(tuned_DFR2P, pred.var = "WK_14_Minweekly_C", grid.resolution = 10) %>% autoplot()
p10
gridExtra::grid.arrange(p3, p4, p5,p6,p7,p8,p9, nrow = 3, ncol = 3)
