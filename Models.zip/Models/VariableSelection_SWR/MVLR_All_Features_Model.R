#Potohar district data analysis
#might have to run other distrits analysis
library(dataRetrieval)
library(xts)
library(timeDate)
library(lubridate)
library(ggplot2)
library(raster)
library(rgdal)
library(sf)
library(maptools)
library(mapproj)
library(maps)
library(sp)
library(RColorBrewer)
library(viridis)
library(viridisLite)
library(rasterVis)
library(chron)
library(lPotice)
library(ncdf4)
library(rgeos)
library(gridExtra)
library(PBSmapping)
library(na.tools)
library(readxl)
library(writexl)
library(corrplot)
library(dplyr)
library(clusterSim)
library(tidyr)
library(rsample)   # data splitting 
library(ggplot2)   # plotting
library(earth)     # fit MARS models
library(caret)     # automating the tuning process
library(vip)       # variable importance
library(pdp) 
library(caTools)
library(MLmetrics)
library(olsrr)
library(MASS)
library(leaps)
library(openxlsx)
library(broom)

#rounding function
round_df <- function(df, digits) {
  nums <- vapply(df, is.numeric, FUN.VALUE = logical(1))
  
  df[,nums] <- round(df[,nums], digits = digits)
  
  (df)
}

#exploring MARS
#upload data
Potohar_Wheat <- read_excel('C:/Users/Ryan/Box/NASA_WEF/data/Features/Potohar_HR_Features.xlsx')
Potohar_Wheat$Ln_Wheat <- NULL


#Set train data the same as other python models, WK_14_Minweekly_SM_0_10cm
rem1 <- read.csv('C:/Users/Ryan/Box/NASA_WEF/output/V2/RF/Season_Week_Month_top5/DataWithPredictedValues.csv')
rem1 <- rem1$WK_14_Minweekly_SM_0_10cm

#Potohar training datat
Potohar_Wheat <- subset(Potohar_Wheat, !WK_14_Minweekly_SM_0_10cm %in% rem1)



DF <- Potohar_Wheat
Features <- colnames(DF)


#Make a dataframe of step models first____ features
Features1 <- c( 'Feb_Medianmonthly_SM_0_10cm','Jan_Meanmonthly_C','WK_12_Minweekly_C',
          'Jan_Mar_Minmonthly_Airtemp_C','JanandMar_below12mmhr','Feb_monthly_Air_temp_Hrs10_20C',
          'WK_13_Medianweekly_C','Feb_Minmonthly_SM_0_10cm','NovandFeb_STemp_Hrs10_20C',
          'Feb_monthly_Air_temp_Hrs10_15C','Season_Air_temp_Hrs10_20C','WK_14_Medianweekly_C',
          'WK_2_Maxweekly_SM_0_10cm','Jan_Mar_5_8mmhr','DecandMar_below12mmhr',
          'WK_14_weekly_Air_temp_Hrs0_10C','DecandMar_Precip_hours','Jan_Medianmonthly_SM_10_40cm',
          'NovandMar_1_5mmhr','Mean_Monthly_SM_10_40cm','WK_20_weekly_STemp_Hrs10_20C',
          'Feb_Maxmonthly_SM_0_10cm','WK_19_Minweekly_SM_0_10cm','Dec_Apr_5_8mmhr',
          'WK_20_Minweekly_SM_10_40cm','Feb_Apr_below15mmhr','Feb_Apr_below8mmhr',
          'WK_3_Medianweekly_SM_0_10cm','WK_14_weekly_Hrsabove_10C','WK_20_Maxweekly_SM_0_10cm',
          'JanandMar_Apr_above2mmhr','WK_14_weekly_Air_temp_Hrs10_20C','DecandMar_above2mmhr',
          'WK_21_Meanweekly_SM_10_40cm','MinMonth_Season_STemp_0_10cm','WK_5_Medianweekly_SM_0_10cm',
          'WK_19_weekly_STemp_Hrs15_20C','WK_13_Meanweekly_C','WK_4_Medianweekly_SM_0_10cm',
          'NovandJan_Hrsabove_10C','Jan_Mar_Air_temp_Hrs10_20C','Season_STemp_Hrs10_20C',
          'Feb_Medianmonthly_SM_10_40cm','Feb_Apr_1_5mmhr','WK_7_Minweekly_C',
          'WK_9_Maxweekly_SM_0_10cm','JanandMar_below8mmhr','NovandJanFeb_Hrsbelow_10C',
          'DecandFeb_Mar_5_8mmhr','DecandFeb_Mar_STemp_Hrs10_15C','WK_21_Medianweekly_SM_0_10cm',
          'DecandMar_1_5mmhr','Feb_Mar_STemp_Hrsbelow_5C','WK_17_Minweekly_SM_10_40cm',
          'Jan_Mar_Air_temp_Hrs0_5C','WK_6_Medianweekly_SM_0_10cm','Nov_Feb_Precip_hours',
          'NovandJan_Mar_STemp_Hrs10_20C','Mar_Meanmonthly_SM_0_10cm','DecandFeb_Mar_STemp_Hrs10_20C',
          'WK_14_Minweekly_C','WK_17_Medianweekly_SM_10_40cm','Apr_Maxmonthly_SM_10_40cm',
          'NovandJan_Apr_below15mmhr','WK_23_Maxweekly_SM_10_40cm','Mar_monthly_Precip_below15mmhr',
          'WK_15_Meanweekly_SM_0_10cm', 'Wheat_ton_ha'
)

DF1 <- Potohar_Wheat[Features1]

#R1
#need to remove odd metrics that mess up model or are meaningless
RemFeatures <- c('Feb_Minmonthly_SM_0_10cm', 'DecandMar_below12mmhr',
                  'JanandMar_below12mmhr', 'WK_20_weekly_STemp_Hrs10_20C' )
RemFeatures <- setdiff( Features1,RemFeatures)

#make a dataframe with good metrics
RemFeatures <- Potohar_Wheat[RemFeatures]

#R2
#need to remove odd metrics that mess up model or are meaningless
RemFeatures2 <- c('Feb_Minmonthly_SM_0_10cm', 'DecandMar_below12mmhr',
                 'JanandMar_below12mmhr', 'WK_20_weekly_STemp_Hrs10_20C',
                 'WK_14_weekly_Air_temp_Hrs0_10C',
                 'DecandMar_below12mmhr', 'Feb_monthly_Air_temp_Hrs10_15C',
                 'WK_17_Minweekly_SM_10_40cm', 'WK_13_Meanweekly_C')
RemFeatures2 <- setdiff( Features1,RemFeatures2)


#make a dataframe with good metrics
RemFeatures2 <- Potohar_Wheat[RemFeatures2]
RemFeatures2Feat <- colnames(RemFeatures2)

#R3
#need to remove odd metrics that mess up model or are meaningless, remove  hours between and mmhr
RemFeatures3 <- head(RemFeatures2[,colnames(RemFeatures2)[grep('mmhr',colnames(RemFeatures2))]])
RemFeatures3b <- head(RemFeatures2[,colnames(RemFeatures2)[grep('0_10',colnames(RemFeatures2))]])
RemFeatures3c <- head(RemFeatures2[,colnames(RemFeatures2)[grep('10_15',colnames(RemFeatures2))]])
RemFeatures3d <- head(RemFeatures2[,colnames(RemFeatures2)[grep('0_5',colnames(RemFeatures2))]])
RemFeatures3e <- head(RemFeatures2[,colnames(RemFeatures2)[grep('10_20',colnames(RemFeatures2))]])

RemFeatures3 <- colnames(RemFeatures3)
RemFeatures3b <- colnames(RemFeatures3b)
RemFeatures3c <- colnames(RemFeatures3c)
RemFeatures3d <- colnames(RemFeatures3d)
RemFeatures3e <- colnames(RemFeatures3e)
RemFeatures3 <- setdiff( RemFeatures2Feat,RemFeatures3)
RemFeatures3 <- setdiff( RemFeatures3,RemFeatures3b)
RemFeatures3 <- setdiff( RemFeatures3,RemFeatures3c)
RemFeatures3 <- setdiff( RemFeatures3,RemFeatures3d)
RemFeatures3 <- setdiff( RemFeatures3,RemFeatures3e)

RemFeatures3 <- Potohar_Wheat[RemFeatures3]




#Look at the correlated features of the most important variables, All DF
Features_Cor <- data.frame(cor(DF$Wheat_ton_ha, DF))
Features_Cor <- data.frame(t(Features_Cor))
colnames(Features_Cor) <- 'Correlation'
Features_Cor$Variable <- rownames(Features_Cor)
Features_Cor$Correlation <- abs(Features_Cor$Correlation)
Features_Cor <-  Features_Cor[order(Features_Cor$Correlation,decreasing=TRUE),]

#Look at the correlated features of the most important variables, All DF
Features_Cor1 <- data.frame(cor(DF1$Wheat_ton_ha, DF1))
Features_Cor1 <- data.frame(t(Features_Cor1))
colnames(Features_Cor1) <- 'Correlation'
Features_Cor1$Variable <- rownames(Features_Cor1)
Features_Cor1$Correlation <- abs(Features_Cor1$Correlation)
Features_Cor1 <-  Features_Cor1[order(Features_Cor1$Correlation,decreasing=TRUE),]

#Look at the correlated features of the most important variables, All DF
Features_CorR1 <- data.frame(cor(RemFeatures$Wheat_ton_ha, RemFeatures))
Features_CorR1 <- data.frame(t(Features_CorR1))
colnames(Features_CorR1) <- 'Correlation'
Features_CorR1$Variable <- rownames(Features_CorR1)
Features_CorR1$Correlation <- abs(Features_CorR1$Correlation)
Features_CorR1 <-  Features_CorR1[order(Features_CorR1$Correlation,decreasing=TRUE),]

#Look at the correlated features of the most important variables, All DF
Features_CorR2 <- data.frame(cor(RemFeatures2$Wheat_ton_ha, RemFeatures2))
Features_CorR2 <- data.frame(t(Features_CorR2))
colnames(Features_CorR2) <- 'Correlation'
Features_CorR2$Variable <- rownames(Features_CorR2)
Features_CorR2$Correlation <- abs(Features_CorR2$Correlation)
Features_CorR2 <-  Features_CorR2[order(Features_CorR2$Correlation,decreasing=TRUE),]

#Look at the correlated features of the most important variables, All DF
Features_CorR3 <- data.frame(cor(RemFeatures3$Wheat_ton_ha, RemFeatures3))
Features_CorR3 <- data.frame(t(Features_CorR3))
colnames(Features_CorR3) <- 'Correlation'
Features_CorR3$Variable <- rownames(Features_CorR3)
Features_CorR3$Correlation <- abs(Features_CorR3$Correlation)
Features_CorR3 <-  Features_CorR3[order(Features_CorR3$Correlation,decreasing=TRUE),]




#Take top features to make model. c > 0.40, all precip
Features2 <- subset(Features_Cor, Correlation > 0.40)
Features2 <- Features2$Variable

#Take top features to make model. c > 0.40, all precip
Features2b <- subset(Features_Cor1, Correlation > 0.40)
Features2b <- Features2b$Variable

#Take top features to make model. c > 0.40, all precip
Features2R1 <- subset(Features_CorR1, Correlation > 0.40)
Features2R1 <- Features2R1$Variable

#Take top features to make model. c > 0.40, all precip
Features2R2 <- subset(Features_CorR2, Correlation > 0.40)
Features2R2 <- Features2R2$Variable

#Take top features to make model. c > 0.40, all precip
Features2R3 <- subset(Features_CorR3, Correlation > 0.40)
Features2R3 <- Features2R3$Variable


#building model with just top 20 most correlcated features
DF <- Potohar_Wheat[Features2]
DF1 <- Potohar_Wheat[Features2b]
DFR1 <- Potohar_Wheat[Features2R1]
DFR2 <- Potohar_Wheat[Features2R2]
DFR3 <- Potohar_Wheat[Features2R3]

#Leaps
#All features
#leap Forward
# Set seed for reproducibility
set.seed(123)
# Set up repeated 10 k-fold cross-validation
#This method tunes model based on reducing RMSE
train.control <- trainControl(method = "cv", number = 5)
# Train the model
#methods <- c('leapBackward','leapForward','leapSeq' )
Mod_LF <- train(Wheat_ton_ha ~ ., data=DF,
                method = 'leapForward', 
                tuneGrid = data.frame(nvmax = 1:10),
                trControl = train.control)

Model_STATS_LF <- data.frame(Mod_LF$results)

#determine the best variables
var <- Mod_LF$bestTune
var
Coef_LF <- data.frame(coef(Mod_LF$finalModel, var$nvmax))
Coef_LF$Feature <- rownames(Coef_LF)
Coef_LF <- Coef_LF[,c(2,1)]
rownames(Coef_LF) <- c()
colnames(Coef_LF)[2] <- 'Coefficient'

#make model with these coefs
Coef_LF <- subset(Coef_LF, Feature !='(Intercept)')
Coef_LF[nrow(Coef_LF)+1,] <- c('Wheat_ton_ha', NA)
DF_LF <- DF[Coef_LF$Feature]

#make model as a function of these parameters
All_Mod_LF <- lm(Wheat_ton_ha~., data=DF_LF)
summary(All_Mod_LF)
All_Mod_LF_Stats <- data.frame(tidy(All_Mod_LF))
colnames(All_Mod_LF_Stats) <- c('Variable', 'Coefficient', 'std error', 't_stat', 'p_value')
All_Mod_LF_Stats <- All_Mod_LF_Stats[order(All_Mod_LF_Stats$p_value),]
All_Mod_LF_Stats <- round_df(All_Mod_LF_Stats, digits = 3)

# Set up repeated 10 k-fold cross-validation
#This method tunes model based on reducing RMSE
# Train the model
set.seed(123)
Mod_LB <- train(Wheat_ton_ha ~ ., data=DF,
                method = 'leapBackward', 
                tuneGrid = data.frame(nvmax = 1:10),
                trControl = train.control)

Model_STATS_LB <- data.frame(Mod_LB$results)

#determine the best variables
var <- Mod_LB$bestTune
var
Coef_LB <- data.frame(coef(Mod_LB$finalModel, var$nvmax))
Coef_LB$Feature <- rownames(Coef_LB)
Coef_LB <- Coef_LB[,c(2,1)]
rownames(Coef_LB) <- c()
colnames(Coef_LB)[2] <- 'Coefficient'

#make model with these coefs
Coef_LB <- subset(Coef_LB, Feature !='(Intercept)')
Coef_LB[nrow(Coef_LB)+1,] <- c('Wheat_ton_ha', NA)
DF_LB <- DF[Coef_LB$Feature]


#make model as a function of these parameters
All_Mod_LB <- lm(Wheat_ton_ha~., data=DF_LB)
summary(All_Mod_LB)
All_Mod_LB_Stats <- data.frame(tidy(All_Mod_LB))
colnames(All_Mod_LB_Stats) <- c('Variable', 'Coefficient', 'std error', 't_stat', 'p_value')
All_Mod_LB_Stats <- All_Mod_LB_Stats[order(All_Mod_LB_Stats$p_value),]
All_Mod_LB_Stats <- round_df(All_Mod_LB_Stats, digits = 3)

#BAsic step function no CV
## Full model
mod.1 <- lm(Wheat_ton_ha ~ ., data=DF)
## Null model
mod.0 <- lm(Wheat_ton_ha ~ 1, data=DF)
mod.Final <- step(mod.0, scope = formula(mod.1))
summary(mod.Final)
All_SF_Stats <- data.frame(tidy(mod.Final))
colnames(All_SF_Stats) <- c('Variable', 'Coefficient', 'std error', 't-stat', 'p_value')
All_SF_Stats <- All_SF_Stats[order(All_SF_Stats$p_value),]
All_SF_Stats <- round_df(All_SF_Stats, digits = 3)



#Save All Precipitation Data
list_of_datasets <- list("Model LB" = Model_STATS_LB, "Model_Stats_LB" = All_Mod_LB_Stats,
                         "Model LF" = Model_STATS_LF, "Model_Stats_LF" = All_Mod_LF_Stats,
                         'Model_Stats_SF' = All_SF_Stats)
write.xlsx(list_of_datasets, file = "C:/Users/Ryan/Box/NASA_WEF/output/Cat_R2/AllFeatures.xlsx")





#Leaps
#All features, DF1
#leap Forward
# Set seed for reproducibility
set.seed(123)
# Set up repeated 10 k-fold cross-validation
#This method tunes model based on reducing RMSE
train.control <- trainControl(method = "cv", number = 5)
# Train the model
#methods <- c('leapBackward','leapForward','leapSeq' )
Mod_LF <- train(Wheat_ton_ha ~ ., data=DF1,
                method = 'leapForward', 
                tuneGrid = data.frame(nvmax = 1:10),
                trControl = train.control)

Model_STATS_LF <- data.frame(Mod_LF$results)

#determine the best variables
var <- Mod_LF$bestTune
var
Coef_LF <- data.frame(coef(Mod_LF$finalModel, var$nvmax))
Coef_LF$Feature <- rownames(Coef_LF)
Coef_LF <- Coef_LF[,c(2,1)]
rownames(Coef_LF) <- c()
colnames(Coef_LF)[2] <- 'Coefficient'

#make model with these coefs
Coef_LF <- subset(Coef_LF, Feature !='(Intercept)')
Coef_LF[nrow(Coef_LF)+1,] <- c('Wheat_ton_ha', NA)
DF1_LF <- DF1[Coef_LF$Feature]

#make model as a function of these parameters
All_Mod_LF <- lm(Wheat_ton_ha~., data=DF1_LF)
summary(All_Mod_LF)
All_Mod_LF_Stats <- data.frame(tidy(All_Mod_LF))
colnames(All_Mod_LF_Stats) <- c('Variable', 'Coefficient', 'std error', 't_stat', 'p_value')
All_Mod_LF_Stats <- All_Mod_LF_Stats[order(All_Mod_LF_Stats$p_value),]
All_Mod_LF_Stats <- round_df(All_Mod_LF_Stats, digits = 3)

# Set up repeated 10 k-fold cross-validation
#This method tunes model based on reducing RMSE
# Train the model
set.seed(123)
Mod_LB <- train(Wheat_ton_ha ~ ., data=DF1,
                method = 'leapBackward', 
                tuneGrid = data.frame(nvmax = 1:10),
                trControl = train.control)

Model_STATS_LB <- data.frame(Mod_LB$results)

#determine the best variables
var <- Mod_LB$bestTune
var
Coef_LB <- data.frame(coef(Mod_LB$finalModel, var$nvmax))
Coef_LB$Feature <- rownames(Coef_LB)
Coef_LB <- Coef_LB[,c(2,1)]
rownames(Coef_LB) <- c()
colnames(Coef_LB)[2] <- 'Coefficient'

#make model with these coefs
Coef_LB <- subset(Coef_LB, Feature !='(Intercept)')
Coef_LB[nrow(Coef_LB)+1,] <- c('Wheat_ton_ha', NA)
DF1_LB <- DF1[Coef_LB$Feature]


#make model as a function of these parameters
All_Mod_LB <- lm(Wheat_ton_ha~., data=DF1_LB)
summary(All_Mod_LB)
All_Mod_LB_Stats <- data.frame(tidy(All_Mod_LB))
colnames(All_Mod_LB_Stats) <- c('Variable', 'Coefficient', 'std error', 't_stat', 'p_value')
All_Mod_LB_Stats <- All_Mod_LB_Stats[order(All_Mod_LB_Stats$p_value),]
All_Mod_LB_Stats <- round_df(All_Mod_LB_Stats, digits = 3)

#BAsic step function no CV
## Full model
mod.1 <- lm(Wheat_ton_ha ~ ., data=DF1)
## Null model
mod.0 <- lm(Wheat_ton_ha ~ 1, data=DF1)
mod.Final <- step(mod.0, scope = formula(mod.1))
summary(mod.Final)
All_SF_Stats <- data.frame(tidy(mod.Final))
colnames(All_SF_Stats) <- c('Variable', 'Coefficient', 'std error', 't-stat', 'p_value')
All_SF_Stats <- All_SF_Stats[order(All_SF_Stats$p_value),]
All_SF_Stats <- round_df(All_SF_Stats, digits = 3)



#Save All Precipitation Data
list_of_datasets <- list("Model LB" = Model_STATS_LB, "Model_Stats_LB" = All_Mod_LB_Stats,
                         "Model LF" = Model_STATS_LF, "Model_Stats_LF" = All_Mod_LF_Stats,
                         'Model_Stats_SF' = All_SF_Stats)
write.xlsx(list_of_datasets, file = "C:/Users/Ryan/Box/NASA_WEF/output/Cat_R2/AllFeaturesDF1.xlsx")





#Leaps
#All features, DFR1
#leap Forward
# Set seed for reproducibility
set.seed(123)
# Set up repeated 10 k-fold cross-validation
#This method tunes model based on reducing RMSE
train.control <- trainControl(method = "cv", number = 5)
# Train the model
#methods <- c('leapBackward','leapForward','leapSeq' )
Mod_LF <- train(Wheat_ton_ha ~ ., data=DFR1,
                method = 'leapForward', 
                tuneGrid = data.frame(nvmax = 1:10),
                trControl = train.control)

Model_STATS_LF <- data.frame(Mod_LF$results)

#determine the best variables
var <- Mod_LF$bestTune
var
Coef_LF <- data.frame(coef(Mod_LF$finalModel, var$nvmax))
Coef_LF$Feature <- rownames(Coef_LF)
Coef_LF <- Coef_LF[,c(2,1)]
rownames(Coef_LF) <- c()
colnames(Coef_LF)[2] <- 'Coefficient'

#make model with these coefs
Coef_LF <- subset(Coef_LF, Feature !='(Intercept)')
Coef_LF[nrow(Coef_LF)+1,] <- c('Wheat_ton_ha', NA)
DFR1_LF <- DFR1[Coef_LF$Feature]

#make model as a function of these parameters
All_Mod_LF <- lm(Wheat_ton_ha~., data=DFR1_LF)
summary(All_Mod_LF)
All_Mod_LF_Stats <- data.frame(tidy(All_Mod_LF))
colnames(All_Mod_LF_Stats) <- c('Variable', 'Coefficient', 'std error', 't_stat', 'p_value')
All_Mod_LF_Stats <- All_Mod_LF_Stats[order(All_Mod_LF_Stats$p_value),]
All_Mod_LF_Stats <- round_df(All_Mod_LF_Stats, digits = 3)

# Set up repeated 10 k-fold cross-validation
#This method tunes model based on reducing RMSE
# Train the model
set.seed(123)
Mod_LB <- train(Wheat_ton_ha ~ ., data=DFR1,
                method = 'leapBackward', 
                tuneGrid = data.frame(nvmax = 1:10),
                trControl = train.control)

Model_STATS_LB <- data.frame(Mod_LB$results)

#determine the best variables
var <- Mod_LB$bestTune
var
Coef_LB <- data.frame(coef(Mod_LB$finalModel, var$nvmax))
Coef_LB$Feature <- rownames(Coef_LB)
Coef_LB <- Coef_LB[,c(2,1)]
rownames(Coef_LB) <- c()
colnames(Coef_LB)[2] <- 'Coefficient'

#make model with these coefs
Coef_LB <- subset(Coef_LB, Feature !='(Intercept)')
Coef_LB[nrow(Coef_LB)+1,] <- c('Wheat_ton_ha', NA)
DFR1_LB <- DFR1[Coef_LB$Feature]


#make model as a function of these parameters
All_Mod_LB <- lm(Wheat_ton_ha~., data=DFR1_LB)
summary(All_Mod_LB)
All_Mod_LB_Stats <- data.frame(tidy(All_Mod_LB))
colnames(All_Mod_LB_Stats) <- c('Variable', 'Coefficient', 'std error', 't_stat', 'p_value')
All_Mod_LB_Stats <- All_Mod_LB_Stats[order(All_Mod_LB_Stats$p_value),]
All_Mod_LB_Stats <- round_df(All_Mod_LB_Stats, digits = 3)

#BAsic step function no CV
## Full model
mod.1 <- lm(Wheat_ton_ha ~ ., data=DFR1)
## Null model
mod.0 <- lm(Wheat_ton_ha ~ 1, data=DFR1)
mod.Final <- step(mod.0, scope = formula(mod.1))
summary(mod.Final)
All_SF_Stats <- data.frame(tidy(mod.Final))
colnames(All_SF_Stats) <- c('Variable', 'Coefficient', 'std error', 't-stat', 'p_value')
All_SF_Stats <- All_SF_Stats[order(All_SF_Stats$p_value),]
All_SF_Stats <- round_df(All_SF_Stats, digits = 3)
mod.Final$anova


#Save All Precipitation Data
list_of_datasets <- list("Model LB" = Model_STATS_LB, "Model_Stats_LB" = All_Mod_LB_Stats,
                         "Model LF" = Model_STATS_LF, "Model_Stats_LF" = All_Mod_LF_Stats,
                         'Model_Stats_SF' = All_SF_Stats)
write.xlsx(list_of_datasets, file = "C:/Users/Ryan/Box/NASA_WEF/output/Cat_R2/AllFeaturesDFR1.xlsx")






#Leaps
#All features, DFR2
#leap Forward
# Set seed for reproducibility
set.seed(123)
# Set up repeated 10 k-fold cross-validation
#This method tunes model based on reducing RMSE
train.control <- trainControl(method = "cv", number = 5)
# Train the model
#methods <- c('leapBackward','leapForward','leapSeq' )
Mod_LF <- train(Wheat_ton_ha ~ ., data=DFR2,
                method = 'leapForward', 
                tuneGrid = data.frame(nvmax = 1:10),
                trControl = train.control)

Model_STATS_LF <- data.frame(Mod_LF$results)

#determine the best variables
var <- Mod_LF$bestTune
var
Coef_LF <- data.frame(coef(Mod_LF$finalModel, var$nvmax))
Coef_LF$Feature <- rownames(Coef_LF)
Coef_LF <- Coef_LF[,c(2,1)]
rownames(Coef_LF) <- c()
colnames(Coef_LF)[2] <- 'Coefficient'

#make model with these coefs
Coef_LF <- subset(Coef_LF, Feature !='(Intercept)')
Coef_LF[nrow(Coef_LF)+1,] <- c('Wheat_ton_ha', NA)
DFR2_LF <- DFR2[Coef_LF$Feature]

#make model as a function of these parameters
All_Mod_LF <- lm(Wheat_ton_ha~., data=DFR2_LF)
summary(All_Mod_LF)
All_Mod_LF_Stats <- data.frame(tidy(All_Mod_LF))
colnames(All_Mod_LF_Stats) <- c('Variable', 'Coefficient', 'std error', 't_stat', 'p_value')
All_Mod_LF_Stats <- All_Mod_LF_Stats[order(All_Mod_LF_Stats$p_value),]
All_Mod_LF_Stats <- round_df(All_Mod_LF_Stats, digits = 3)

# Set up repeated 10 k-fold cross-validation
#This method tunes model based on reducing RMSE
# Train the model
set.seed(123)
Mod_LB <- train(Wheat_ton_ha ~ ., data=DFR2,
                method = 'leapBackward', 
                tuneGrid = data.frame(nvmax = 1:10),
                trControl = train.control)

Model_STATS_LB <- data.frame(Mod_LB$results)

#determine the best variables
var <- Mod_LB$bestTune
var
Coef_LB <- data.frame(coef(Mod_LB$finalModel, var$nvmax))
Coef_LB$Feature <- rownames(Coef_LB)
Coef_LB <- Coef_LB[,c(2,1)]
rownames(Coef_LB) <- c()
colnames(Coef_LB)[2] <- 'Coefficient'

#make model with these coefs
Coef_LB <- subset(Coef_LB, Feature !='(Intercept)')
Coef_LB[nrow(Coef_LB)+1,] <- c('Wheat_ton_ha', NA)
DFR2_LB <- DFR2[Coef_LB$Feature]


#make model as a function of these parameters
All_Mod_LB <- lm(Wheat_ton_ha~., data=DFR2_LB)
summary(All_Mod_LB)
All_Mod_LB_Stats <- data.frame(tidy(All_Mod_LB))
colnames(All_Mod_LB_Stats) <- c('Variable', 'Coefficient', 'std error', 't_stat', 'p_value')
All_Mod_LB_Stats <- All_Mod_LB_Stats[order(All_Mod_LB_Stats$p_value),]
All_Mod_LB_Stats <- round_df(All_Mod_LB_Stats, digits = 3)

#BAsic step function no CV
## Full model
mod.1 <- lm(Wheat_ton_ha ~ ., data=DFR2)
## Null model
mod.0 <- lm(Wheat_ton_ha ~ 1, data=DFR2)
mod.Final <- step(mod.0, scope = formula(mod.1))
summary(mod.Final)
All_SF_Stats <- data.frame(tidy(mod.Final))
colnames(All_SF_Stats) <- c('Variable', 'Coefficient', 'std error', 't-stat', 'p_value')
All_SF_Stats <- All_SF_Stats[order(All_SF_Stats$p_value),]
All_SF_Stats <- round_df(All_SF_Stats, digits = 3)



#Save All Precipitation Data
list_of_datasets <- list("Model LB" = Model_STATS_LB, "Model_Stats_LB" = All_Mod_LB_Stats,
                         "Model LF" = Model_STATS_LF, "Model_Stats_LF" = All_Mod_LF_Stats,
                         'Model_Stats_SF' = All_SF_Stats)
write.xlsx(list_of_datasets, file = "C:/Users/Ryan/Box/NASA_WEF/output/Cat_R2/AllFeaturesDFR2.xlsx")





#Leaps
#All features, DFR3
#leap Forward
# Set seed for reproducibility
set.seed(123)
# Set up repeated 10 k-fold cross-validation
#This method tunes model based on reducing RMSE
train.control <- trainControl(method = "cv", number = 5)
# Train the model
#methods <- c('leapBackward','leapForward','leapSeq' )
Mod_LF <- train(Wheat_ton_ha ~ ., data=DFR3,
                method = 'leapForward', 
                tuneGrid = data.frame(nvmax = 1:10),
                trControl = train.control)

Model_STATS_LF <- data.frame(Mod_LF$results)

#determine the best variables
var <- Mod_LF$bestTune
var
Coef_LF <- data.frame(coef(Mod_LF$finalModel, var$nvmax))
Coef_LF$Feature <- rownames(Coef_LF)
Coef_LF <- Coef_LF[,c(2,1)]
rownames(Coef_LF) <- c()
colnames(Coef_LF)[2] <- 'Coefficient'

#make model with these coefs
Coef_LF <- subset(Coef_LF, Feature !='(Intercept)')
Coef_LF[nrow(Coef_LF)+1,] <- c('Wheat_ton_ha', NA)
DFR3_LF <- DFR3[Coef_LF$Feature]

#make model as a function of these parameters
All_Mod_LF <- lm(Wheat_ton_ha~., data=DFR3_LF)
summary(All_Mod_LF)
All_Mod_LF_Stats <- data.frame(tidy(All_Mod_LF))
colnames(All_Mod_LF_Stats) <- c('Variable', 'Coefficient', 'std error', 't_stat', 'p_value')
All_Mod_LF_Stats <- All_Mod_LF_Stats[order(All_Mod_LF_Stats$p_value),]
All_Mod_LF_Stats <- round_df(All_Mod_LF_Stats, digits = 3)

# Set up repeated 10 k-fold cross-validation
#This method tunes model based on reducing RMSE
# Train the model
set.seed(123)
Mod_LB <- train(Wheat_ton_ha ~ ., data=DFR3,
                method = 'leapBackward', 
                tuneGrid = data.frame(nvmax = 1:10),
                trControl = train.control)

Model_STATS_LB <- data.frame(Mod_LB$results)

#determine the best variables
var <- Mod_LB$bestTune
var
Coef_LB <- data.frame(coef(Mod_LB$finalModel, var$nvmax))
Coef_LB$Feature <- rownames(Coef_LB)
Coef_LB <- Coef_LB[,c(2,1)]
rownames(Coef_LB) <- c()
colnames(Coef_LB)[2] <- 'Coefficient'

#make model with these coefs
Coef_LB <- subset(Coef_LB, Feature !='(Intercept)')
Coef_LB[nrow(Coef_LB)+1,] <- c('Wheat_ton_ha', NA)
DFR3_LB <- DFR3[Coef_LB$Feature]


#make model as a function of these parameters
All_Mod_LB <- lm(Wheat_ton_ha~., data=DFR3_LB)
summary(All_Mod_LB)
All_Mod_LB_Stats <- data.frame(tidy(All_Mod_LB))
colnames(All_Mod_LB_Stats) <- c('Variable', 'Coefficient', 'std error', 't_stat', 'p_value')
All_Mod_LB_Stats <- All_Mod_LB_Stats[order(All_Mod_LB_Stats$p_value),]
All_Mod_LB_Stats <- round_df(All_Mod_LB_Stats, digits = 3)

#BAsic step function no CV
## Full model
mod.1 <- lm(Wheat_ton_ha ~ ., data=DFR3)
## Null model
mod.0 <- lm(Wheat_ton_ha ~ 1, data=DFR3)
mod.Final <- step(mod.0, scope = formula(mod.1))
summary(mod.Final)
All_SF_Stats <- data.frame(tidy(mod.Final))
colnames(All_SF_Stats) <- c('Variable', 'Coefficient', 'std error', 't-stat', 'p_value')
All_SF_Stats <- All_SF_Stats[order(All_SF_Stats$p_value),]
All_SF_Stats <- round_df(All_SF_Stats, digits = 3)



#Save All Precipitation Data
list_of_datasets <- list("Model LB" = Model_STATS_LB, "Model_Stats_LB" = All_Mod_LB_Stats,
                         "Model LF" = Model_STATS_LF, "Model_Stats_LF" = All_Mod_LF_Stats,
                         'Model_Stats_SF' = All_SF_Stats)
write.xlsx(list_of_datasets, file = "C:/Users/Ryan/Box/NASA_WEF/output/Cat_R2/AllFeaturesDFR3.xlsx")


#find some stats as a function of the best model AF_DFR1_SF, using training data
#Find each features % contribution to yield
DFR1_SF <- c('WK_14_Minweekly_C','WK_15_Meanweekly_SM_0_10cm','JanandMar_below8mmhr',
             'MinMonth_Season_STemp_0_10cm', 'Wheat_ton_ha' )
DFR1_SF <- Potohar_Wheat[DFR1_SF]

#find coef*features values 
WK_14_Minweekly_Ccoef <-  0.0569
WK_15_Meanweekly_SM_0_10cmcoef<- 0.025
JanandMar_below8mmhrcoef  <- 0.006479
MinMonth_Season_STemp_0_10cmcoef  <-  0.0988854
DFR1_SF$WK_14_Minweekly_C_INF <- WK_14_Minweekly_Ccoef*DFR1_SF$WK_14_Minweekly_C
DFR1_SF$WK_15_Meanweekly_SM_0_10cm_INF <- WK_15_Meanweekly_SM_0_10cmcoef*DFR1_SF$WK_15_Meanweekly_SM_0_10cm
DFR1_SF$JanandMar_below8mmhr_INF <- JanandMar_below8mmhrscoef*DFR1_SF$JanandMar_below8mmhr
DFR1_SF$MinMonth_Season_STemp_0_10cm_INF <- MinMonth_Season_STemp_0_10cmcoef*DFR1_SF$MinMonth_Season_STemp_0_10cm

#calculate contributing influence as a percentage (not taking into account an intercept)
DFR1_SF$FeatureTotal <- DFR1_SF$WK_14_Minweekly_C_INF+DFR1_SF$WK_15_Meanweekly_SM_0_10cm_INF+
  DFR1_SF$JanandMar_below8mmhr_INF+DFR1_SF$MinMonth_Season_STemp_0_10cm_INF
#feature importance as a function of all contributing features
DFR1_SF$WK_14_Minweekly_C_Perc <- 100*(DFR1_SF$WK_14_Minweekly_C_INF/DFR1_SF$FeatureTotal)
DFR1_SF$WK_15_Meanweekly_SM_0_10cm_Perc <- 100*(DFR1_SF$WK_15_Meanweekly_SM_0_10cm_INF/DFR1_SF$FeatureTotal)
DFR1_SF$JanandMar_below8mmhr_Perc <- 100*(DFR1_SF$JanandMar_below8mmhr_INF/DFR1_SF$FeatureTotal)
DFR1_SF$MinMonth_Season_STemp_0_10cm_Perc <- 100*(DFR1_SF$MinMonth_Season_STemp_0_10cm_INF/DFR1_SF$FeatureTotal)



WK_14_Minweekly_Cstats <- c(
  WK_14_Minweekly_Ccoef,
  min(DFR1_SF$WK_14_Minweekly_C),
  mean(DFR1_SF$WK_14_Minweekly_C),
  median(DFR1_SF$WK_14_Minweekly_C),
  max(DFR1_SF$WK_14_Minweekly_C),
  min(DFR1_SF$WK_14_Minweekly_C_INF),
  mean(DFR1_SF$WK_14_Minweekly_C_INF),
  median(DFR1_SF$WK_14_Minweekly_C_INF),
  max(DFR1_SF$WK_14_Minweekly_C_INF),
  min(DFR1_SF$WK_14_Minweekly_C_Perc),
  mean(DFR1_SF$WK_14_Minweekly_C_Perc),
  median(DFR1_SF$WK_14_Minweekly_C_Perc),
  max(DFR1_SF$WK_14_Minweekly_C_Perc)
  )

WK_15_Meanweekly_SM_0_10cmstats <- c(
  WK_15_Meanweekly_SM_0_10cmcoef,
  min(DFR1_SF$WK_15_Meanweekly_SM_0_10cm),
  mean(DFR1_SF$WK_15_Meanweekly_SM_0_10cm),
  median(DFR1_SF$WK_15_Meanweekly_SM_0_10cm),
  max(DFR1_SF$WK_15_Meanweekly_SM_0_10cm),
  min(DFR1_SF$WK_15_Meanweekly_SM_0_10cm_INF),
  mean(DFR1_SF$WK_15_Meanweekly_SM_0_10cm_INF),
  median(DFR1_SF$WK_15_Meanweekly_SM_0_10cm_INF),
  max(DFR1_SF$WK_15_Meanweekly_SM_0_10cm_INF),
  min(DFR1_SF$WK_15_Meanweekly_SM_0_10cm_Perc),
  mean(DFR1_SF$WK_15_Meanweekly_SM_0_10cm_Perc),
  median(DFR1_SF$WK_15_Meanweekly_SM_0_10cm_Perc),
  max(DFR1_SF$WK_15_Meanweekly_SM_0_10cm_Perc)
)



JanandMar_below8mmhrtats  <- c(
  JanandMar_below8mmhrcoef,
  min(DFR1_SF$JanandMar_below8mmhr),
  mean(DFR1_SF$JanandMar_below8mmhr),
  median(DFR1_SF$JanandMar_below8mmhr),
  max(DFR1_SF$JanandMar_below8mmhr),
  min(DFR1_SF$JanandMar_below8mmhr_INF),
  mean(DFR1_SF$JanandMar_below8mmhr_INF),
  median(DFR1_SF$JanandMar_below8mmhr_INF),
  max(DFR1_SF$JanandMar_below8mmhr_INF),
  min(DFR1_SF$JanandMar_below8mmhr_Perc),
  mean(DFR1_SF$JanandMar_below8mmhr_Perc),
  median(DFR1_SF$JanandMar_below8mmhr_Perc),
  max(DFR1_SF$JanandMar_below8mmhr_Perc)
)



MinMonth_Season_STemp_0_10cmstats  <- c(
  MinMonth_Season_STemp_0_10cmcoef,
  min(DFR1_SF$MinMonth_Season_STemp_0_10cm),
  mean(DFR1_SF$MinMonth_Season_STemp_0_10cm),
  median(DFR1_SF$MinMonth_Season_STemp_0_10cm),
  max(DFR1_SF$MinMonth_Season_STemp_0_10cm),
  min(DFR1_SF$MinMonth_Season_STemp_0_10cm_INF),
  mean(DFR1_SF$MinMonth_Season_STemp_0_10cm_INF),
  median(DFR1_SF$MinMonth_Season_STemp_0_10cm_INF),
  max(DFR1_SF$MinMonth_Season_STemp_0_10cm_INF),
  min(DFR1_SF$MinMonth_Season_STemp_0_10cm_Perc),
  mean(DFR1_SF$MinMonth_Season_STemp_0_10cm_Perc),
  median(DFR1_SF$MinMonth_Season_STemp_0_10cm_Perc),
  max(DFR1_SF$MinMonth_Season_STemp_0_10cm_Perc)
)

Intercept <- c(0.181, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA)


FeatureStats_DFR1_SF <- data.frame(WK_14_Minweekly_C=WK_14_Minweekly_Cstats)
colnames(FeatureStats_DFR1_SF) <- 'WK_14_Minweekly_C'
rownames(FeatureStats_DFR1_SF) <- c('Coef',
                                    'Min Obs', 'Mean Obs', 'Median Obs', 'Max Obs',
                                    'Min Cont', 'Mean Cont', 'Median Cont', 'Max Cont',
                                    'Min Perc', 'Mean Perc', 'Median Perc', 'Max Perc')
FeatureStats_DFR1_SF$Stat <- rownames(FeatureStats_DFR1_SF)
FeatureStats_DFR1_SF <- FeatureStats_DFR1_SF[,c(2,1)]
rownames(FeatureStats_DFR1_SF) <- NULL

FeatureStats_DFR1_SF$WK_15_Meanweekly_SM_0_10cms <- WK_15_Meanweekly_SM_0_10cmstats
FeatureStats_DFR1_SF$JanandMar_below8mmhr <- JanandMar_below8mmhrtats
FeatureStats_DFR1_SF$MinMonth_Season_STemp_0_10cm <- MinMonth_Season_STemp_0_10cmstats
FeatureStats_DFR1_SF$Intercept <- Intercept

                                   
write.xlsx(FeatureStats_DFR1_SF, file = "C:/Users/Ryan/Box/NASA_WEF/output/Step/FeatureStats_DFR1_SF.xlsx")
