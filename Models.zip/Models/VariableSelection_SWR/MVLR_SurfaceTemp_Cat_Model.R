#Potohar district data analysis
#might have to run other distrits analysis
library(dataRetrieval)
library(xts)
library(timeDate)
library(lubridate)
library(ggplot2)
library(raster)
library(rgdal)
library(sf)
library(maptools)
library(mapproj)
library(maps)
library(sp)
library(RColorBrewer)
library(viridis)
library(viridisLite)
library(rasterVis)
library(chron)
library(lPotice)
library(ncdf4)
library(rgeos)
library(gridExtra)
library(PBSmapping)
library(na.tools)
library(readxl)
library(writexl)
library(corrplot)
library(dplyr)
library(clusterSim)
library(tidyr)
library(rsample)   # data splitting 
library(ggplot2)   # plotting
library(earth)     # fit MARS models
library(caret)     # automating the tuning process
library(vip)       # variable importance
library(pdp) 
library(caTools)
library(MLmetrics)
library(olsrr)
library(MASS)
library(leaps)
library(openxlsx)
library(broom)

#rounding function
round_df <- function(df, digits) {
  nums <- vapply(df, is.numeric, FUN.VALUE = logical(1))
  
  df[,nums] <- round(df[,nums], digits = digits)
  
  (df)
}

#exploring MARS
#upload data
Potohar_Wheat <- read_excel('C:/Users/Ryan/Box/NASA_WEF/data/Features/Potohar_HR_Features.xlsx')
Potohar_Wheat$Ln_Wheat <- NULL

#Set train data the same as other python models, WK_14_Minweekly_SM_0_10cm
rem1 <- read.csv('C:/Users/Ryan/Box/NASA_WEF/output/V2/RF/Season_Week_Month_top5/DataWithPredictedValues.csv')
rem1 <- rem1$WK_14_Minweekly_SM_0_10cm

#Potohar training datat
Potohar_Wheat <- subset(Potohar_Wheat, !WK_14_Minweekly_SM_0_10cm %in% rem1)


#Selecting only Precip
#subset the data to just deal with features of importance and yield
require(PerformanceAnalytics)
Features <- head(Potohar_Wheat[,c('Wheat_ton_ha', 
                                  colnames(Potohar_Wheat)[grep('STemp',colnames(Potohar_Wheat))]
)])
Features <- colnames(Features)


#make a Potohar wheat DF of just Precipitation
DF <- Potohar_Wheat[Features]

#need to remove odd metrics that mess up model or are meaningless
RemFeatures <- c('Jan_Apr_STemp_Hrs10_20C','Feb_Apr_STemp_Hrs0_5C')
RemFeatures <- setdiff( Features,RemFeatures)
#make a dataframe without off air temps
RemFeatures <- Potohar_Wheat[RemFeatures]



#Look at the correlated features of the most important variables, All DF
Features_Cor <- data.frame(cor(DF$Wheat_ton_ha, DF))
Features_Cor <- data.frame(t(Features_Cor))
colnames(Features_Cor) <- 'Correlation'
Features_Cor$Variable <- rownames(Features_Cor)
Features_Cor$Correlation <- abs(Features_Cor$Correlation)
Features_Cor <-  Features_Cor[order(Features_Cor$Correlation,decreasing=TRUE),]

#Look at the correlated features of the most important variables, All DF
Features_CorR1 <- data.frame(cor(DF$Wheat_ton_ha, RemFeatures))
Features_CorR1 <- data.frame(t(Features_CorR1))
colnames(Features_CorR1) <- 'Correlation'
Features_CorR1$Variable <- rownames(Features_CorR1)
Features_CorR1$Correlation <- abs(Features_CorR1$Correlation)
Features_CorR1 <-  Features_CorR1[order(Features_CorR1$Correlation,decreasing=TRUE),]



#Take top features to make model. c > 0.40, all precip
Features2 <- subset(Features_Cor, Correlation > 0.40)
Features2 <- Features2$Variable

#Take top features to make model. c > 0.40, all precip
Features2R1 <- subset(Features_CorR1, Correlation > 0.40)
Features2R1 <- Features2R1$Variable


#building model with just top most correlcated features
DF <- Potohar_Wheat[Features2]
DFR1 <- Potohar_Wheat[Features2R1]


#Leaps
#All Surface temp
#leap Forward
# Set seed for reproducibility
set.seed(123)
# Set up repeated 10 k-fold cross-validation
#This method tunes model based on reducing RMSE
train.control <- trainControl(method = "cv", number = 5)
# Train the model
#methods <- c('leapBackward','leapForward','leapSeq' )
Mod_LF <- train(Wheat_ton_ha ~ ., data=DF,
                method = 'leapForward', 
                tuneGrid = data.frame(nvmax = 1:10),
                trControl = train.control)

Model_STATS_LF <- data.frame(Mod_LF$results)

#determine the best variables
var <- Mod_LF$bestTune
var
Coef_LF <- data.frame(coef(Mod_LF$finalModel, var$nvmax))
Coef_LF$Feature <- rownames(Coef_LF)
Coef_LF <- Coef_LF[,c(2,1)]
rownames(Coef_LF) <- c()
colnames(Coef_LF)[2] <- 'Coefficient'

#make model with these coefs
Coef_LF <- subset(Coef_LF, Feature !='(Intercept)')
Coef_LF[nrow(Coef_LF)+1,] <- c('Wheat_ton_ha', NA)
DF_LF <- DF[Coef_LF$Feature]

#make model as a function of these parameters
All_Mod_LF <- lm(Wheat_ton_ha~., data=DF_LF)
summary(All_Mod_LF)
All_Mod_LF_Stats <- data.frame(tidy(All_Mod_LF))
colnames(All_Mod_LF_Stats) <- c('Variable', 'Coefficient', 'std error', 't_stat', 'p_value')
All_Mod_LF_Stats <- All_Mod_LF_Stats[order(All_Mod_LF_Stats$p_value),]
All_Mod_LF_Stats <- round_df(All_Mod_LF_Stats, digits = 3)

# Set up repeated 10 k-fold cross-validation
#This method tunes model based on reducing RMSE
# Train the model
set.seed(123)
Mod_LB <- train(Wheat_ton_ha ~ ., data=DF,
                method = 'leapBackward', 
                tuneGrid = data.frame(nvmax = 1:10),
                trControl = train.control)

Model_STATS_LB <- data.frame(Mod_LB$results)

#determine the best variables
var <- Mod_LB$bestTune
var
Coef_LB <- data.frame(coef(Mod_LB$finalModel, var$nvmax))
Coef_LB$Feature <- rownames(Coef_LB)
Coef_LB <- Coef_LB[,c(2,1)]
rownames(Coef_LB) <- c()
colnames(Coef_LB)[2] <- 'Coefficient'

#make model with these coefs
Coef_LB <- subset(Coef_LB, Feature !='(Intercept)')
Coef_LB[nrow(Coef_LB)+1,] <- c('Wheat_ton_ha', NA)
DF_LB <- DF[Coef_LB$Feature]


#make model as a function of these parameters
All_Mod_LB <- lm(Wheat_ton_ha~., data=DF_LB)
summary(All_Mod_LB)
All_Mod_LB_Stats <- data.frame(tidy(All_Mod_LB))
colnames(All_Mod_LB_Stats) <- c('Variable', 'Coefficient', 'std error', 't_stat', 'p_value')
All_Mod_LB_Stats <- All_Mod_LB_Stats[order(All_Mod_LB_Stats$p_value),]
All_Mod_LB_Stats <- round_df(All_Mod_LB_Stats, digits = 3)

#BAsic step function no CV
## Full model
mod.1 <- lm(Wheat_ton_ha ~ ., data=DF)
## Null model
mod.0 <- lm(Wheat_ton_ha ~ 1, data=DF)
mod.Final <- step(mod.0, scope = formula(mod.1))
summary(mod.Final)
All_SF_Stats <- data.frame(tidy(mod.Final))
colnames(All_SF_Stats) <- c('Variable', 'Coefficient', 'std error', 't-stat', 'p_value')
All_SF_Stats <- All_SF_Stats[order(All_SF_Stats$p_value),]
All_SF_Stats <- round_df(All_SF_Stats, digits = 3)



#Save All Precipitation Data
list_of_datasets <- list("Model LB" = Model_STATS_LB, "Model_Stats_LB" = All_Mod_LB_Stats,
                         "Model LF" = Model_STATS_LF, "Model_Stats_LF" = All_Mod_LF_Stats,
                         'Model_Stats_SF' = All_SF_Stats)
write.xlsx(list_of_datasets, file = "C:/Users/Ryan/Box/NASA_WEF/output/Cat_R2/SurfaceTempDFR1.xlsx")









#Leaps
#Air temp, odd AT remo
#leap Forward
# Set seed for reproducibility
set.seed(123)
# Train the model
Mod_LF <- train(Wheat_ton_ha ~ ., data=DFR1,
                method = 'leapForward', 
                tuneGrid = data.frame(nvmax = 1:10),
                trControl = train.control)

Model_STATS_LF <- data.frame(Mod_LF$results)

#determine the best variables
var <- Mod_LF$bestTune
var
Coef_LF <- data.frame(coef(Mod_LF$finalModel, var$nvmax))
Coef_LF$Feature <- rownames(Coef_LF)
Coef_LF <- Coef_LF[,c(2,1)]
rownames(Coef_LF) <- c()
colnames(Coef_LF)[2] <- 'Coefficient'

#make model with these coefs
Coef_LF <- subset(Coef_LF, Feature !='(Intercept)')
Coef_LF[nrow(Coef_LF)+1,] <- c('Wheat_ton_ha', NA)
DFR1_LF <- DFR1[Coef_LF$Feature]


#make model as a function of these parameters
AdjMod_LF <- lm(Wheat_ton_ha~., data=DFR1_LF)
summary(AdjMod_LF)
AdjMod_LF_Stats <- data.frame(tidy(AdjMod_LF))
colnames(AdjMod_LF_Stats) <- c('Variable', 'Coefficient', 'std error', 't_stat', 'p_value')
AdjMod_LF_Stats <- AdjMod_LF_Stats[order(AdjMod_LF_Stats$p_value),]
AdjMod_LF_Stats <- round_df(AdjMod_LF_Stats, digits = 3)


#leap Backwards
# Set seed for reproducibility
set.seed(123)
# Train the model
Mod_LB <- train(Wheat_ton_ha ~ ., data=DFR1,
                method = 'leapBackward', 
                tuneGrid = data.frame(nvmax = 1:10),
                trControl = train.control)

Model_STATS_LB <- data.frame(Mod_LB$results)

#determine the best variables
var <- Mod_LB$bestTune
var
Coef_LB <- data.frame(coef(Mod_LB$finalModel, var$nvmax))
Coef_LB$Feature <- rownames(Coef_LB)
Coef_LB <- Coef_LB[,c(2,1)]
rownames(Coef_LB) <- c()
colnames(Coef_LB)[2] <- 'Coefficient'

#make model with these coefs
Coef_LB <- subset(Coef_LB, Feature !='(Intercept)')
Coef_LB[nrow(Coef_LB)+1,] <- c('Wheat_ton_ha', NA)
DFR1_LB <- DFR1[Coef_LB$Feature]

#make model as a function of these parameters
AdjMod_LB <- lm(Wheat_ton_ha~., data=DFR1_LB)
summary(AdjMod_LB)
AdjMod_LB_Stats <- data.frame(tidy(AdjMod_LB))
colnames(AdjMod_LB_Stats) <- c('Variable', 'Coefficient', 'std error', 't_stat', 'p_value')
AdjMod_LB_Stats <- AdjMod_LB_Stats[order(AdjMod_LB_Stats$p_value),]
AdjMod_LB_Stats <- round_df(AdjMod_LB_Stats, digits = 3)


#BAsic step function no CV
## Full model
mod.1 <- lm(Wheat_ton_ha ~ ., data=DFR1)
## Null model
mod.0 <- lm(Wheat_ton_ha ~ 1, data=DFR1)
mod.Final <- step(mod.0, scope = formula(mod.1))
summary(mod.Final)
AdjMod_SF_Stats <- data.frame(tidy(mod.Final))
colnames(AdjMod_SF_Stats) <- c('Variable', 'Coefficient', 'std error', 't-stat', 'p_value')
AdjMod_SF_Stats <- AdjMod_SF_Stats[order(AdjMod_SF_Stats$p_value),]
AdjMod_SF_Stats <- round_df(AdjMod_SF_Stats, digits = 3)



#Save All Precipitation Data
list_of_datasets <- list("Model LB" = Model_STATS_LB, "Model_Stats_LB" = AdjMod_LB_Stats,
                         "Model LF" = Model_STATS_LF, "Model_Stats_LF" = AdjMod_LF_Stats,
                         'Model_AdjMod_SF_Stats' = AdjMod_SF_Stats)
write.xlsx(list_of_datasets, file = "C:/Users/Ryan/Box/NASA_WEF/output/Cat_R2/SurfaceTempDFR2.xlsx")











